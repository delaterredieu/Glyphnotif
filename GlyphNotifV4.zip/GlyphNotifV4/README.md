# GlyphNotif V4

Appli Android (Kotlin / Jetpack Compose) : allume la Glyph du Nothing Phone (1) selon des règles
sur les notifications (appli, contacts, type de notification, mot-clé).

Nouveautés V4 : durée de la lumière réglable finement, extraits de sons (début / durée libres, passage favori),
synchronisation son / lumière, fenêtres de choix centrées avec recherche, contacts d'une appli,
types de notification propres à chaque appli, écran de détail d'un son avec diagnostic,
terrain préparé pour la V4.1 (règles masquées + authentification).

## Mise en route
1. Copier le .aar du Glyph Developer Kit dans `app/libs/` (supprimer le fichier texte qui s'y trouve).
2. Ouvrir ce dossier dans Android Studio (File > Open), laisser Gradle synchroniser.
3. Téléphone branché (débogage USB), cliquer sur le triangle vert Run.

L'identifiant de l'appli est inchangé : la V4 remplace la V3 sur le téléphone en gardant règles et réglages
(les règles des versions précédentes sont converties automatiquement).
