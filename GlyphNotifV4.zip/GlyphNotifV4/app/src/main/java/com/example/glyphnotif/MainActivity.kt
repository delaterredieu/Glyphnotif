package com.example.glyphnotif

import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.fragment.app.FragmentActivity
import java.util.Collections

sealed interface Dest {
    data object Home : Dest
    data class Editor(val rule: Rule, val isNew: Boolean) : Dest
    data object Defaults : Dest
    data object Settings : Dest
    data object Permissions : Dest
    data object GlyphSettings : Dest
    data object Sounds : Dest
    data class SoundEditor(val ref: String) : Dest
    data object Appearance : Dest
    data object Background : Dest
    data object Logo : Dest
    data object Backup : Dest
    data object Security : Dest
}

// FragmentActivity (et non ComponentActivity) : nécessaire pour l'authentification biométrique de la V4.1
class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppSettings.load(this)
        SoundLibrary.load(this)
        enableEdgeToEdge()
        GlyphController.start(this)
        setContent { AppTheme { App() } }
    }

    override fun onResume() {
        super.onResume()
        GlyphDev.ensure(this)
        AppState.resumeTick++
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var rules by remember { mutableStateOf(RuleStore.load(ctx)) }
    val stack = remember { mutableStateListOf<Dest>(Dest.Home) }

    fun push(d: Dest) { stack.add(d) }
    fun pop() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }
    fun persist(list: List<Rule>) {
        rules = list
        RuleStore.save(ctx, list)
    }

    BackHandler(enabled = stack.size > 1) { pop() }

    when (val d = stack.last()) {
        Dest.Home -> HomeScreen(
            rules = rules,
            onToggle = { r -> persist(rules.map { if (it.id == r.id) it.copy(enabled = !it.enabled) else it }) },
            onEdit = { push(Dest.Editor(it, false)) },
            onMove = { r, delta ->
                val i = rules.indexOfFirst { it.id == r.id }
                val j = i + delta
                if (i >= 0 && j in rules.indices) persist(rules.toMutableList().also { Collections.swap(it, i, j) })
            },
            onDelete = { r -> persist(rules.filter { it.id != r.id }) },
            onAdd = { push(Dest.Editor(RuleStore.newRule(ctx), true)) },
            onSettings = { push(Dest.Settings) }
        )
        is Dest.Editor -> EditorScreen(
            initial = d.rule,
            isNew = d.isNew,
            template = false,
            onSave = { n ->
                persist(if (rules.any { it.id == n.id }) rules.map { if (it.id == n.id) n else it } else rules + n)
                SoundPlayer.stopPreview()
                pop()
            },
            onCancel = { GlyphController.stopTest(); SoundPlayer.stopRule(); SoundPlayer.stopPreview(); pop() },
            onDelete = {
                GlyphController.stopTest()
                SoundPlayer.stopRule()
                SoundPlayer.stopPreview()
                persist(rules.filter { it.id != d.rule.id })
                pop()
            }
        )
        Dest.Defaults -> EditorScreen(
            initial = RuleStore.loadTemplate(ctx),
            isNew = false,
            template = true,
            onSave = { n -> RuleStore.saveTemplate(ctx, n); SoundPlayer.stopPreview(); pop() },
            onCancel = { GlyphController.stopTest(); SoundPlayer.stopRule(); SoundPlayer.stopPreview(); pop() },
            onDelete = {}
        )
        Dest.Settings -> SettingsRoot(onBack = { pop() }, onOpen = { push(it) })
        Dest.Permissions -> PermissionsScreen { pop() }
        Dest.GlyphSettings -> GlyphScreen { pop() }
        Dest.Sounds -> SoundsScreen(onBack = { pop() }, onOpenSound = { push(Dest.SoundEditor(it)) })
        is Dest.SoundEditor -> SoundEditorScreen(d.ref) { pop() }
        Dest.Appearance -> AppearanceScreen { pop() }
        Dest.Background -> BackgroundScreen { pop() }
        Dest.Logo -> LogoScreen { pop() }
        Dest.Backup -> BackupScreen(onBack = { pop() }, onRestored = { rules = RuleStore.load(ctx) })
        Dest.Security -> SecurityScreen { pop() }
    }
}
