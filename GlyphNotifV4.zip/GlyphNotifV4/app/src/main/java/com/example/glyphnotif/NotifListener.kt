package com.example.glyphnotif

import android.app.Notification
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Process
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Écoute toutes les notifications (y compris celles de l'appli SMS : le titre contient
 * le nom du contact ou le numéro). Aucune permission SMS n'est nécessaire.
 */
class NotifListener : NotificationListenerService() {

    companion object {
        /** Service connecté (null si l'accès aux notifications n'est pas actif). */
        @Volatile var instance: NotifListener? = null
    }

    private var registered = false
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var renewJob: Job? = null

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_ON -> GlyphController.onScreenOn()
                Intent.ACTION_USER_PRESENT -> GlyphController.onUnlock()
            }
        }
    }

    override fun onListenerConnected() {
        instance = this
        GlyphController.start(this)
        AppSettings.load(this)
        SoundLibrary.load(this)
        // Réactive seul le mode développeur de la Glyph (si l'autorisation a été accordée une fois par adb)
        GlyphDev.ensure(this)
        renewJob?.cancel()
        renewJob = serviceScope.launch {
            while (true) {
                delay(6L * 3600 * 1000)
                GlyphDev.ensure(this@NotifListener)
            }
        }
        if (!registered) {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            registered = true
        }
    }

    override fun onListenerDisconnected() {
        instance = null
        renewJob?.cancel()
        unregister()
        GlyphController.stopAll()
        requestRebind(ComponentName(this, NotifListener::class.java))
    }

    override fun onDestroy() {
        instance = null
        renewJob?.cancel()
        unregister()
        super.onDestroy()
    }

    private fun unregister() {
        if (registered) {
            try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
            registered = false
        }
    }

    /** Types de notification (canaux) d'une appli, comme dans les réglages de notifications d'Android. */
    fun channelsOf(pkg: String): List<ChannelInfo> = try {
        val user = Process.myUserHandle()
        val groups = getNotificationChannelGroups(pkg, user).associate { it.id to it.name?.toString() }
        getNotificationChannels(pkg, user).map { ch ->
            ChannelInfo(ch.id, ch.name?.toString() ?: ch.id, ch.group?.let { g -> groups[g] })
        }
    } catch (e: Exception) {
        emptyList()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (sbn.isOngoing) return

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        val category = n.category.orEmpty()
        val channelId = n.channelId.orEmpty()

        // On retient les conversations et les types vus, pour les proposer dans les menus de l'éditeur de règle
        RecentStore.addTitle(this, sbn.packageName, title)
        try {
            val rk = NotificationListenerService.Ranking()
            if (currentRanking.getRanking(sbn.key, rk)) {
                rk.channel?.let { RecentStore.addChannel(this, sbn.packageName, it.id, it.name?.toString() ?: it.id) }
            }
        } catch (_: Exception) {
        }

        // La première règle qui correspond (dans l'ordre de la liste) s'applique.
        val rule = RuleStore.load(this).firstOrNull {
            it.matches(sbn.packageName, title, text, category, channelId)
        } ?: return

        GlyphController.play(rule, sbn.key)
    }

    /** Notification fermée, ouverte (clic) ou retirée par son appli : la lumière persistante s'arrête. */
    override fun onNotificationRemoved(
        sbn: StatusBarNotification,
        rankingMap: NotificationListenerService.RankingMap,
        reason: Int
    ) {
        GlyphController.released(sbn.key)
    }
}
