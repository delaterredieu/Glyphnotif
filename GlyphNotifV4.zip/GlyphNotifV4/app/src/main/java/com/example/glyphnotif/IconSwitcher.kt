package com.example.glyphnotif

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

object IconSwitcher {
    /** Change l'icône du lanceur parmi la banque de logos. Le lanceur peut mettre quelques secondes à se rafraîchir. */
    fun apply(ctx: Context, index: Int) {
        val pm = ctx.packageManager
        fun comp(i: Int) = ComponentName(ctx, "${ctx.packageName}.Icon${'A' + i}")
        // on active d'abord la nouvelle icône pour ne jamais se retrouver sans lanceur
        pm.setComponentEnabledSetting(comp(index), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
        LOGOS.indices.filter { it != index }.forEach {
            pm.setComponentEnabledSetting(comp(it), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
        }
    }
}
