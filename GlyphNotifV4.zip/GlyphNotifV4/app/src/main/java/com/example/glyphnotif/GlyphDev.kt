package com.example.glyphnotif

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

/**
 * Réactivation automatique du mode développeur de la Glyph (réglage système de Nothing).
 * Nécessite l'autorisation WRITE_SECURE_SETTINGS, à accorder une seule fois par adb :
 *   adb shell pm grant com.example.glyphnotif android.permission.WRITE_SECURE_SETTINGS
 * Usage personnel : ce mode contourne la limite de 48 h prévue par le SDK de Nothing.
 */
object GlyphDev {
    private const val KEY = "nt_glyph_interface_debug_enable"
    private const val PREFS = "glyphdev"
    private const val RENEW_AFTER_MS = 24L * 3600 * 1000

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun canWrite(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

    fun isEnabled(ctx: Context): Boolean = try {
        Settings.Global.getInt(ctx.contentResolver, KEY, 0) == 1
    } catch (e: Exception) {
        false
    }

    fun lastRenewMs(ctx: Context): Long = prefs(ctx).getLong("last", 0L)

    /** Active le mode développeur ; restart = true l'éteint puis le rallume pour relancer le compte à rebours. */
    fun enable(ctx: Context, restart: Boolean): Boolean {
        if (!canWrite(ctx)) return false
        return try {
            val cr = ctx.contentResolver
            if (restart && isEnabled(ctx)) Settings.Global.putInt(cr, KEY, 0)
            val ok = Settings.Global.putInt(cr, KEY, 1)
            if (ok) prefs(ctx).edit().putLong("last", System.currentTimeMillis()).apply()
            ok
        } catch (e: Exception) {
            false
        }
    }

    /** Réactive le mode s'il est éteint, ou s'il l'a été il y a plus de 24 h. Renvoie true si une action a été faite. */
    fun ensure(ctx: Context): Boolean {
        if (!canWrite(ctx)) return false
        val age = System.currentTimeMillis() - lastRenewMs(ctx)
        val acted = when {
            !isEnabled(ctx) -> enable(ctx, false)
            age > RENEW_AFTER_MS -> enable(ctx, true)
            else -> false
        }
        if (acted) GlyphController.reconnect(ctx)
        return acted
    }
}
