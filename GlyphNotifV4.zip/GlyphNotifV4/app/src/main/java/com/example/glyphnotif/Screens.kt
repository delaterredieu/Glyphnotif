package com.example.glyphnotif

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

val Red = Color(0xFFFF3B30)
val Green = Color(0xFF34C759)

// ====================================================================== ACCUEIL

@Composable
fun HomeScreen(
    rules: List<Rule>,
    onToggle: (Rule) -> Unit,
    onEdit: (Rule) -> Unit,
    onMove: (Rule, Int) -> Unit,
    onDelete: (Rule) -> Unit,
    onAdd: () -> Unit,
    onSettings: () -> Unit
) {
    val p = LocalPalette.current
    var menuRule by remember { mutableStateOf<Rule?>(null) }
    val shown = rules.visibleRules()

    Page(
        title = AppSettings.homeTitle.ifBlank { "Règles" },
        trailing = { DotsButton(onSettings) },
        titleLeading = if (AppSettings.showLogoInApp) ({ LauncherPreview(LOGOS[AppSettings.logoIndex.coerceIn(0, LOGOS.lastIndex)].res, 40.dp) }) else null,
        bottomSpace = 110.dp,
        fab = { AddFab(onAdd) }
    ) {
        if (shown.isEmpty()) {
            GroupCard {
                Text(
                    "Aucune règle pour l'instant.\nAppuie sur + pour en créer une.",
                    color = p.secondary, fontSize = 16.sp,
                    modifier = Modifier.fillMaxWidth().padding(24.dp)
                )
            }
        } else {
            GroupCard {
                shown.forEachIndexed { i, r ->
                    if (i > 0) Separator()
                    RuleRow(r, onToggle = { onToggle(r) }, onEdit = { onEdit(r) }, onLongClick = { menuRule = r })
                }
            }
            SectionFooter("La première règle qui correspond (de haut en bas) s'applique. Appui long sur une règle : monter, descendre, supprimer.")
        }
    }

    menuRule?.let { r ->
        ActionDialog(
            r.name,
            listOf(
                DialogAction("Monter") { onMove(r, -1) },
                DialogAction("Descendre") { onMove(r, 1) },
                DialogAction("Supprimer", destructive = true) { onDelete(r) }
            ),
            onDismiss = { menuRule = null }
        )
    }
}

@Composable
private fun RuleRow(r: Rule, onToggle: () -> Unit, onEdit: () -> Unit, onLongClick: () -> Unit) {
    val ctx = LocalContext.current
    val app = remember(r.pkg) { if (r.pkg.isEmpty()) "Toutes les applis" else appLabel(ctx, r.pkg) }
    val mode = r.mode.label.substringBefore(" (")
    val channel = if (r.channelName.isNotEmpty()) " · ${r.channelName}" else ""
    val sound = if (r.sound.isNotEmpty()) " · son" else ""
    RowItem(
        title = r.name,
        subtitle = "$app$channel · $mode · ${r.persistSummary()}$sound",
        leading = if (AppSettings.showAppIcons) ({
            if (r.pkg.isEmpty()) AllAppsIcon(36.dp) else AppIcon(r.pkg, 36.dp)
        }) else null,
        trailing = { AppSwitch(r.enabled) { onToggle() } },
        onClick = onEdit,
        onLongClick = onLongClick
    )
}

// ====================================================================== ÉDITEUR DE RÈGLE

/**
 * Éditeur d'une règle. En mode [template], il édite les valeurs par défaut des nouvelles règles
 * (sans nom ni filtre de notification).
 */
@Composable
fun EditorScreen(
    initial: Rule,
    isNew: Boolean,
    template: Boolean,
    onSave: (Rule) -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit
) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val scope = rememberCoroutineScope()
    var r by remember(initial.id) { mutableStateOf(initial) }
    var pickApp by remember { mutableStateOf(false) }
    var pickSound by remember { mutableStateOf(false) }
    var pickContacts by remember { mutableStateOf(false) }
    val apps = remember { loadApps(ctx) }
    val appName = if (r.pkg.isEmpty()) "Toutes les applis" else (apps.firstOrNull { it.pkg == r.pkg }?.label ?: r.pkg)
    val contacts = r.contacts()

    var soundTotal by remember(r.sound) { mutableIntStateOf(0) }
    LaunchedEffect(r.sound) {
        soundTotal = if (r.sound.isEmpty()) 0 else withContext(Dispatchers.IO) { SoundLibrary.durationMs(ctx, r.sound) }
    }
    val fav = remember(r.sound) { SoundMeta.getFav(ctx, r.sound) }
    val maxT = if (soundTotal > 0) soundTotal else 600_000
    val timeStep = if (maxT > 60_000) 1000 else 500

    DisposableEffect(Unit) { onDispose { SoundPlayer.stopPreview() } }

    Page(
        title = when {
            template -> "Valeurs par défaut"
            isNew -> "Nouvelle règle"
            else -> "Modifier"
        },
        backLabel = if (template) "Réglages" else "Règles",
        onBack = onCancel,
        trailing = {
            Text(
                "Enregistrer", color = p.accent, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { GlyphController.stopTest(); onSave(r) }.padding(8.dp)
            )
        }
    ) {
        if (template) {
            SectionFooter("Ces valeurs sont appliquées à chaque nouvelle règle que tu crées. Les règles existantes ne changent pas.")
        } else {
            GroupCard { FieldRow("Nom", r.name, "Nouvelle règle") { r = r.copy(name = it) } }

            SectionHeader("Quand une notification arrive")
            GroupCard {
                NavRow(
                    "Appli", value = appName,
                    leading = { if (r.pkg.isEmpty()) AllAppsIcon(30.dp) else AppIcon(r.pkg, 30.dp) }
                ) { pickApp = true }
                Separator()
                NavRow(
                    "Contacts",
                    value = when {
                        contacts.isEmpty() -> "Tous"
                        contacts.size == 1 -> contacts[0]
                        else -> "${contacts.size} contacts"
                    }
                ) { pickContacts = true }
                Separator()
                FieldRow("Texte", r.textContains, "Tous") { r = r.copy(textContains = it) }
                Separator()
                if (r.pkg.isNotEmpty()) {
                    ChannelRow(r.pkg, r.channelId, r.channelName) { id, name -> r = r.copy(channelId = id, channelName = name) }
                } else {
                    ChoiceRow("Catégorie", CATEGORIES.map { Choice(it.first, it.second) }, r.category) { r = r.copy(category = it) }
                }
            }
            SectionFooter("Contacts : choisis dans ceux de l'appli, dans les conversations déjà vues dans ses notifications, ou dans tes contacts ; tu peux aussi saisir un nom. Type de notification : les types propres à l'appli, comme dans les réglages de notifications d'Android (disponibles quand une appli est choisie).")
        }

        SectionHeader("Préréglages")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PRESETS.forEach { pr ->
                TintedAction(pr.name) { r = r.copy(leds = pr.leds, mode = pr.mode, periodMs = pr.periodMs) }
            }
        }

        SectionHeader("LED à allumer")
        GroupCard {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                (0 until ZONE_COUNT).chunked(5).forEach { line ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        line.forEach { i ->
                            val on = i in r.leds
                            Box(
                                Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(10.dp))
                                    .background(if (on) p.accent else p.chip)
                                    .clickable { r = r.copy(leds = if (on) r.leds - i else r.leds + i) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    ZONE_LABELS[i], fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                                    color = if (on) Color.White else p.text
                                )
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TintedAction("Toutes") { r = r.copy(leds = ALL_LEDS) }
                    TintedAction("Aucune") { r = r.copy(leds = emptySet()) }
                }
            }
        }
        if (r.leds.isEmpty() && r.mode != Mode.TONE) SectionFooter("Sélectionne au moins une LED, sinon la règle ne s'allumera jamais.")

        SectionHeader("Animation")
        GroupCard {
            ChoiceRow("Animation", Mode.values().map { Choice(it.name, it.label) }, r.mode.name) { r = r.copy(mode = Mode.valueOf(it)) }
            Separator()
            SliderRow("Vitesse", "${r.periodMs} ms", r.periodMs.toFloat(), 100f..3000f) { r = r.copy(periodMs = it.toInt()) }
        }
        if (r.mode == Mode.TONE) {
            SectionFooter("« Motif du son » rejoue la lumière contenue dans le fichier du son choisi (un glyphtone importé dans Réglages > Sons, ou un son du téléphone si son fichier la contient). Sans motif lisible, la Glyph respire doucement : vérifie avec Réglages > Sons > (le son) > Diagnostic du motif.")
        }

        SectionHeader("Persistance de la lumière")
        GroupCard {
            Box(Modifier.padding(12.dp)) {
                Segmented(Persist.values().map { it.label }, r.persist.ordinal) { r = r.copy(persist = Persist.values()[it]) }
            }
            if (r.persist == Persist.TIMED) {
                Separator()
                DurationRow("Durée de la lumière", r.durationMs) { r = r.copy(durationMs = it) }
                Separator()
                SwitchRow("Arrêter si la notification est fermée ou ouverte", null, r.stopOnRemoval) { r = r.copy(stopOnRemoval = it) }
            }
            Separator()
            SwitchRow("Arrêter quand j'allume l'écran", null, r.stopOnScreenOn) { r = r.copy(stopOnScreenOn = it) }
            Separator()
            SwitchRow("Arrêter quand je déverrouille le téléphone", null, r.stopOnUnlock) { r = r.copy(stopOnUnlock = it) }
        }
        SectionFooter(
            when (r.persist) {
                Persist.TIMED -> "La lumière s'éteint après la durée choisie, ou plus tôt si une des conditions d'arrêt est remplie."
                Persist.UNTIL_REMOVED -> "La lumière reste allumée tant que la notification est dans le volet. Elle s'arrête quand tu l'ouvres, la balaies, ou que son appli la retire."
                Persist.INFINITE -> "Pour les notifications d'extrême importance : aucune limite de temps. La lumière (et le son, si tu le répètes) continue jusqu'à ce que la notification soit ouverte, balayée ou retirée, et elle reste prioritaire sur les autres règles. Laisse les deux options d'écran désactivées pour qu'un simple déverrouillage ne l'arrête pas."
            }
        )
        SectionFooter("Android ne signale pas l'ouverture du volet de notifications : « vue » veut dire ouverte, balayée ou retirée, ou, si tu les actives, écran allumé / téléphone déverrouillé. Si une notification allume elle-même l'écran, l'option « écran allumé » coupe la lumière aussitôt.")

        SectionHeader("Son")
        GroupCard {
            NavRow("Son", value = SoundLibrary.nameFor(ctx, r.sound)) { pickSound = true }
            if (r.sound.isNotEmpty()) {
                Separator()
                Box(Modifier.padding(12.dp)) {
                    Segmented(SoundSpan.values().map { it.label }, r.soundSpan.ordinal) { r = r.copy(soundSpan = SoundSpan.values()[it]) }
                }
                when (r.soundSpan) {
                    SoundSpan.FULL -> {}
                    SoundSpan.FAVORITE -> {
                        Separator()
                        RowItem(
                            title = if (fav != null) "Passage favori : ${fmtTime(fav.first)} · ${fmtDur(fav.second)}" else "Aucun passage favori défini",
                            subtitle = if (fav == null) "Définis-le dans Réglages > Sons > (ce son). Sans favori, le son est joué en entier." else null
                        )
                    }
                    SoundSpan.CUSTOM -> {
                        Separator()
                        TimeSliderRow("Début de l'extrait", r.soundStartMs, maxT, timeStep) {
                            r = r.copy(soundStartMs = it, soundLenMs = minOf(r.soundLenMs, (maxT - it).coerceAtLeast(500)))
                        }
                        Separator()
                        TimeSliderRow("Durée de l'extrait", r.soundLenMs, (maxT - r.soundStartMs).coerceAtLeast(500), timeStep) {
                            r = r.copy(soundLenMs = it.coerceAtLeast(500))
                        }
                    }
                }
                Separator()
                Box(Modifier.padding(12.dp)) {
                    Segmented(SoundTiming.values().map { it.label }, r.soundTiming.ordinal) { r = r.copy(soundTiming = SoundTiming.values()[it]) }
                }
                Separator()
                SliderRow("Volume", "${r.soundVolume} %", r.soundVolume.toFloat(), 0f..100f) { r = r.copy(soundVolume = it.toInt()) }
                Separator()
                SliderRow(
                    "Répéter le son (pause entre deux)",
                    if (r.soundRepeatSec == 0) "Non" else "${r.soundRepeatSec} s",
                    r.soundRepeatSec.toFloat(), 0f..120f
                ) { r = r.copy(soundRepeatSec = it.toInt()) }
                Separator()
                SwitchRow("Respecter le mode silencieux", null, r.respectSilent) { r = r.copy(respectSilent = it) }
                Separator()
                ActionRow("Écouter le son (extrait compris)") {
                    scope.launch {
                        val seg = withContext(Dispatchers.IO) { SoundLibrary.segment(ctx, r) }
                        SoundPlayer.togglePreview(
                            ctx, "edit:${r.sound}", SoundLibrary.uriFor(ctx, r.sound),
                            seg.first, if (r.soundSpan == SoundSpan.FULL) 0 else seg.second
                        )
                    }
                }
            }
        }
        if (r.sound.isNotEmpty()) {
            SectionFooter(
                when (r.soundTiming) {
                    SoundTiming.INDEPENDENT -> "Le son et la lumière ont chacun leur durée : le son joue l'extrait choisi, la lumière dure le temps réglé plus haut."
                    SoundTiming.CUT_WITH_LIGHT -> "Le son est coupé dès que la lumière s'éteint (durée de la lumière réglée plus haut)."
                    SoundTiming.LIGHT_FOLLOWS -> "La lumière dure exactement le temps du son ou de l'extrait. Ne s'applique qu'en mode « Durée »."
                }
            )
        }
        SectionFooter("Le son d'origine de l'autre appli n'est pas remplacé : coupe-le dans les réglages de notifications d'Android si tu ne veux entendre que le tien.")

        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledAction("Tester") { GlyphController.play(r.copy(enabled = true), null) }
            TintedAction("Stop") { GlyphController.stopTest(); SoundPlayer.stopRule(); SoundPlayer.stopPreview() }
        }

        if (!isNew && !template) {
            Spacer(Modifier.height(20.dp))
            GroupCard { ActionRow("Supprimer la règle", color = Red) { onDelete() } }
        }
    }

    if (pickApp) {
        AppPickerDialog(apps, onPick = { r = r.copy(pkg = it, channelId = "", channelName = ""); pickApp = false }, onDismiss = { pickApp = false })
    }
    if (pickSound) {
        SoundPickerDialog(r.sound, onPick = { r = r.copy(sound = it); pickSound = false }, onDismiss = { pickSound = false })
    }
    if (pickContacts) {
        ContactPickerDialog(
            r.pkg, contacts,
            onDone = { r = r.copy(titleContains = it.joinToString("\n")); pickContacts = false },
            onDismiss = { pickContacts = false }
        )
    }
}
