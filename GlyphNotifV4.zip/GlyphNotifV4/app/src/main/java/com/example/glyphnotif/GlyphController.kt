package com.example.glyphnotif

import android.content.ComponentName
import android.content.Context
import android.os.SystemClock
import android.util.Log
import com.nothing.ketchum.Common
import com.nothing.ketchum.Glyph
import com.nothing.ketchum.GlyphFrame
import com.nothing.ketchum.GlyphManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Enveloppe autour du Glyph Developer Kit (Nothing Phone (1)).
 *
 * Règles d'affichage :
 *  - un motif à durée fixe (TIMED) s'affiche par-dessus tout le reste, puis les motifs persistants reprennent ;
 *  - les motifs persistants (jusqu'à fermeture / infini) restent actifs tant que leur notification existe ;
 *  - un motif INFINI est toujours prioritaire sur un motif « jusqu'à fermeture ».
 */
object GlyphController {
    private const val TAG = "GlyphController"

    private var gm: GlyphManager? = null
    private var appCtx: Context? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    @Volatile var ready = false
        private set

    private class Active(
        val key: String,
        val rule: Rule,
        val seq: Long,
        val track: GlyphTrack? = null,   // aperçu d'un glyphtone
        val offsetMs: Int = 0,
        val lenMs: Int = 0
    ) {
        @Volatile var soundDone = false
    }

    private val actives = LinkedHashMap<String, Active>() // motifs persistants, par clé de notification
    private var temp: Active? = null                     // motif à durée fixe en cours
    private var shown: Active? = null                    // ce qui est affiché maintenant
    private var seq = 0L

    private val callback = object : GlyphManager.Callback {
        override fun onServiceConnected(name: ComponentName?) {
            try {
                if (Common.is20111()) gm?.register(Glyph.DEVICE_20111)
                gm?.openSession()
                ready = true
            } catch (e: Exception) {
                Log.w(TAG, "Initialisation Glyph impossible", e)
                ready = false
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            ready = false
            try { gm?.closeSession() } catch (_: Exception) {}
        }
    }

    @Synchronized
    fun start(ctx: Context) {
        appCtx = ctx.applicationContext
        if (gm != null) return
        val m = GlyphManager.getInstance(ctx.applicationContext)
        gm = m
        m.init(callback)
    }

    /** Ferme puis rouvre la connexion au SDK Glyph (utile après réactivation du mode développeur). */
    @Synchronized
    fun reconnect(ctx: Context) {
        try { gm?.closeSession() } catch (_: Exception) {}
        try { gm?.unInit() } catch (_: Exception) {}
        gm = null
        ready = false
        start(ctx)
    }

    // ------------------------------------------------------------ entrées

    /** Une règle correspond à une notification (key) ou à un test (key == null). */
    @Synchronized
    fun play(rule: Rule, key: String?) {
        if (gm == null || !ready) return
        if (rule.mode != Mode.TONE && rule.leds.isEmpty()) return
        val a = Active(key ?: "test", rule, seq++)
        if (rule.persist == Persist.TIMED) {
            actives.remove(a.key)
            temp = a
            show(a)
        } else {
            actives[a.key] = a
            temp = null
            showTop()
        }
    }

    /** Aperçu lumineux d'un glyphtone (extrait de offsetMs sur lenMs ; lenMs = 0 : jusqu'à la fin). */
    @Synchronized
    fun previewTrack(track: GlyphTrack, offsetMs: Int = 0, lenMs: Int = 0) {
        if (gm == null || !ready) return
        val total = track.durationMs(AppSettings.toneFrameMs).toInt()
        val len = if (lenMs > 0) lenMs else (total - offsetMs).coerceAtLeast(500)
        val rule = Rule(mode = Mode.TONE, persist = Persist.TIMED, durationMs = len + 500)
        val a = Active("preview", rule, seq++, track, offsetMs, len)
        temp = a
        show(a)
    }

    /** La notification a été fermée, ouverte ou retirée par son appli. */
    @Synchronized
    fun released(key: String) {
        actives.remove(key)
        val t = temp
        if (t != null && t.key == key && t.rule.stopOnRemoval) temp = null
        refreshDisplay()
    }

    @Synchronized fun onScreenOn() = seen { it.stopOnScreenOn }
    @Synchronized fun onUnlock() = seen { it.stopOnUnlock }

    @Synchronized fun stopTest() = stopKey("test")
    @Synchronized fun stopPreviewLight() = stopKey("preview")

    @Synchronized
    fun stopAll() {
        actives.clear()
        temp = null
        show(null)
    }

    // ------------------------------------------------------------ logique interne

    private fun stopKey(key: String) {
        actives.remove(key)
        if (temp?.key == key) temp = null
        refreshDisplay()
    }

    private fun seen(pred: (Rule) -> Boolean) {
        var changed = false
        val iter = actives.values.iterator()
        while (iter.hasNext()) {
            if (pred(iter.next().rule)) { iter.remove(); changed = true }
        }
        val t = temp
        if (t != null && pred(t.rule)) { temp = null; changed = true }
        if (changed) refreshDisplay()
    }

    private fun top(): Active? {
        val inf = actives.values.filter { it.rule.persist == Persist.INFINITE }.maxByOrNull { it.seq }
        return inf ?: actives.values.maxByOrNull { it.seq }
    }

    private fun refreshDisplay() {
        if (temp != null) return
        showTop()
    }

    private fun showTop() {
        val t = top()
        if (t != null && t === shown) return
        show(t)
    }

    private fun show(a: Active?) {
        shown = a
        val m = gm
        val previous = job
        previous?.cancel()
        job = scope.launch {
            previous?.join()
            if (m == null) return@launch
            if (a == null) off(m) else runActive(m, a)
        }
    }

    @Synchronized
    private fun finished(a: Active) {
        if (temp === a) temp = null
        if (shown === a) shown = null
        refreshDisplay()
    }

    private fun off(m: GlyphManager) {
        try { m.turnOff() } catch (_: Exception) {}
    }

    private fun frame(m: GlyphManager, leds: List<Int>, period: Int = 1000, cycles: Int = 1): GlyphFrame {
        val b = m.getGlyphFrameBuilder()
        leds.forEach { b.buildChannel(it) }
        return b.buildPeriod(period).buildCycles(cycles).buildInterval(0).build()
    }

    private suspend fun runActive(m: GlyphManager, a: Active) {
        val rule = a.rule
        val ctx = appCtx
        var natural = false
        val soundJob = if (ctx != null && rule.sound.isNotEmpty() && a.track == null) scope.launch { soundLoop(ctx, a) } else null
        try {
            runPattern(m, a)
            natural = true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Erreur pendant le motif", e)
        } finally {
            withContext(NonCancellable) {
                soundJob?.cancel()
                // Le son va jusqu'au bout après une fin naturelle, sauf si on l'a lié à la lumière
                if (!natural || rule.soundTiming == SoundTiming.CUT_WITH_LIGHT) SoundPlayer.stopRule()
                off(m)
                if (natural) finished(a)
            }
        }
    }

    /** Joue le son (extrait compris), puis le répète avec une pause si la règle le demande. */
    private suspend fun soundLoop(ctx: Context, a: Active) {
        val rule = a.rule
        val (start, len) = SoundLibrary.segment(ctx, rule)
        if (!a.soundDone) {
            a.soundDone = true
            playOnce(ctx, rule, start, len)
        }
        if (rule.soundRepeatSec > 0) {
            while (true) {
                delay(rule.soundRepeatSec * 1000L)
                playOnce(ctx, rule, start, len)
            }
        }
    }

    private suspend fun playOnce(ctx: Context, rule: Rule, start: Int, len: Int) {
        // La coupure à la fin de l'extrait est faite par le lecteur de son : elle ne dépend pas de la lumière.
        val cut = if (rule.soundSpan != SoundSpan.FULL && len > 0) len else 0
        if (!SoundPlayer.playRule(ctx, rule, start, cut)) return
        // Pour répéter le son, on attend la fin de la lecture avant de compter la pause.
        if (rule.soundRepeatSec > 0 && len > 0) delay(len.toLong())
    }

    private suspend fun runPattern(m: GlyphManager, a: Active) {
        val rule = a.rule
        val ctx = appCtx
        val persistent = rule.persist != Persist.TIMED
        val seg = if (a.track == null && ctx != null && rule.sound.isNotEmpty()) SoundLibrary.segment(ctx, rule) else null
        var lightMs = if (rule.durationMs > 0) rule.durationMs.toLong() else 10_000L
        if (!persistent && rule.soundTiming == SoundTiming.LIGHT_FOLLOWS && seg != null && seg.second > 0) {
            lightMs = seg.second.toLong()
        }
        val end = if (persistent) Long.MAX_VALUE else SystemClock.elapsedRealtime() + lightMs
        fun left() = end - SystemClock.elapsedRealtime()
        val leds = rule.leds.sorted()
        val period = rule.periodMs.coerceIn(100, 10_000)

        when (rule.mode) {
            Mode.STATIC -> {
                m.toggle(frame(m, leds))
                if (persistent) awaitCancellation() else delay(left())
            }
            Mode.BREATHE -> while (left() > 0) {
                val cycles = if (persistent) 10 else maxOf(1L, minOf(10L, left() / period)).toInt()
                m.animate(frame(m, leds, period, cycles))
                delay(period.toLong() * cycles)
            }
            Mode.BLINK -> while (left() > 0) {
                m.toggle(frame(m, leds))
                delay(minOf(left(), period / 2L))
                m.turnOff()
                delay(minOf(left().coerceAtLeast(0L), period / 2L))
            }
            Mode.CHASE -> {
                val step = maxOf(80L, period.toLong() / leds.size)
                while (left() > 0) {
                    for (l in leds) {
                        if (left() <= 0) break
                        m.toggle(frame(m, listOf(l)))
                        delay(step)
                    }
                }
            }
            Mode.TONE -> {
                val track = a.track ?: (if (ctx != null) SoundLibrary.glyphTrack(ctx, rule.sound) else null)
                if (track == null || track.frames.isEmpty()) {
                    val all = ALL_LEDS.sorted()
                    while (left() > 0) {
                        m.animate(frame(m, all, 2000, 1))
                        delay(2000)
                    }
                } else {
                    val off = if (a.track != null) a.offsetMs else (seg?.first ?: 0)
                    val len = if (a.track != null) a.lenMs else (seg?.second ?: 0)
                    while (left() > 0) playTrackOnce(m, track, end, off, len)
                }
            }
        }
    }

    /** Joue une fois le motif lumineux d'un glyphtone, de offsetMs sur lenMs (0 = jusqu'à la fin). Allumé / éteint, sans intensité. */
    private suspend fun playTrackOnce(m: GlyphManager, track: GlyphTrack, end: Long, offsetMs: Int, lenMs: Int) {
        val frameMs = AppSettings.toneFrameMs.coerceAtLeast(1)
        val thr = track.max * AppSettings.toneThreshold / 100
        val trackTotal = track.frames.size.toLong() * frameMs
        val from = offsetMs.toLong().coerceIn(0L, trackTotal)
        val to = if (lenMs > 0) minOf(trackTotal, from + lenMs) else trackTotal
        val span = to - from
        if (span <= 0) {
            delay(100)
            return
        }
        val t0 = SystemClock.elapsedRealtime()
        var last: Set<Int>? = null
        while (true) {
            val now = SystemClock.elapsedRealtime()
            val el = now - t0
            if (el >= span || now >= end) break
            val idx = ((from + el) / frameMs).toInt().coerceAtMost(track.frames.size - 1)
            val set = Glyphtone.ledsFor(track.frames[idx], track.columns, thr)
            if (set != last) {
                if (set.isEmpty()) m.turnOff() else m.toggle(frame(m, set.sorted()))
                last = set
            }
            delay(8)
        }
    }
}
