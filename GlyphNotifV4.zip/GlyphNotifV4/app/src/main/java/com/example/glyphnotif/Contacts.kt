package com.example.glyphnotif

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

data class ChannelInfo(val id: String, val name: String, val group: String?)

/** Mémoire locale de ce qui a été vu dans les notifications : titres de conversations et types (canaux). */
object RecentStore {
    private const val PREFS = "recent"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun readList(ctx: Context, key: String): List<String> = try {
        val a = JSONArray(prefs(ctx).getString(key, "[]") ?: "[]")
        (0 until a.length()).map { a.getString(it) }
    } catch (e: Exception) {
        emptyList()
    }

    fun addTitle(ctx: Context, pkg: String, title: String) {
        val t = title.trim()
        if (t.isEmpty() || t.length > 80) return
        val key = "t:$pkg"
        val list = readList(ctx, key).toMutableList()
        if (list.firstOrNull() == t) return
        list.remove(t)
        list.add(0, t)
        while (list.size > 80) list.removeAt(list.lastIndex)
        prefs(ctx).edit().putString(key, JSONArray(list).toString()).apply()
    }

    fun titles(ctx: Context, pkg: String): List<String> = readList(ctx, "t:$pkg")

    fun addChannel(ctx: Context, pkg: String, id: String, name: String) {
        val key = "c:$pkg"
        val o = try { JSONObject(prefs(ctx).getString(key, "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        if (o.optString(id) == name) return
        o.put(id, name)
        prefs(ctx).edit().putString(key, o.toString()).apply()
    }

    fun channels(ctx: Context, pkg: String): List<Pair<String, String>> = try {
        val o = JSONObject(prefs(ctx).getString("c:$pkg", "{}") ?: "{}")
        o.keys().asSequence().map { it to o.optString(it) }.toList()
    } catch (e: Exception) {
        emptyList()
    }
}

/** Types de notification (canaux Android) d'une appli, tels qu'ils apparaissent dans les réglages d'Android. */
object NotifChannels {
    fun forPackage(ctx: Context, pkg: String): List<ChannelInfo> {
        val live = NotifListener.instance?.channelsOf(pkg) ?: emptyList()
        if (live.isNotEmpty()) return live.sortedBy { it.name.lowercase() }
        return RecentStore.channels(ctx, pkg).map { ChannelInfo(it.first, it.second, null) }.sortedBy { it.name.lowercase() }
    }
}

/** Contacts du téléphone (permission « Contacts » nécessaire). */
object Contacts {
    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    /** Tous les contacts du téléphone. */
    fun all(ctx: Context): List<String> {
        val out = LinkedHashSet<String>()
        try {
            ctx.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                arrayOf(ContactsContract.Contacts.DISPLAY_NAME_PRIMARY),
                null, null,
                "${ContactsContract.Contacts.DISPLAY_NAME_PRIMARY} COLLATE NOCASE ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) out.add(n)
                }
            }
        } catch (e: Exception) {
        }
        return out.toList()
    }

    /** Contacts « de l'appli » : ceux qu'une appli de messagerie (WhatsApp, Signal, Telegram…) a synchronisés dans le téléphone. */
    fun forAccount(ctx: Context, accountType: String): List<String> {
        val out = LinkedHashSet<String>()
        try {
            ctx.contentResolver.query(
                ContactsContract.RawContacts.CONTENT_URI,
                arrayOf(ContactsContract.RawContacts.DISPLAY_NAME_PRIMARY),
                "${ContactsContract.RawContacts.ACCOUNT_TYPE} = ? AND ${ContactsContract.RawContacts.DELETED} = 0",
                arrayOf(accountType),
                "${ContactsContract.RawContacts.DISPLAY_NAME_PRIMARY} COLLATE NOCASE ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) out.add(n)
                }
            }
        } catch (e: Exception) {
        }
        return out.toList()
    }
}

/** Passages favoris des sons (début et durée en ms), par référence de son. */
object SoundMeta {
    private const val PREFS = "soundmeta"
    private const val KEY = "fav"

    private fun read(ctx: Context): JSONObject = try {
        JSONObject(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    private fun write(ctx: Context, o: JSONObject) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    fun getFav(ctx: Context, ref: String): Pair<Int, Int>? {
        val o = read(ctx).optJSONObject(ref) ?: return null
        val len = o.optInt("len", 0)
        return if (len > 0) o.optInt("start", 0) to len else null
    }

    fun setFav(ctx: Context, ref: String, start: Int, len: Int) {
        val o = read(ctx)
        o.put(ref, JSONObject().put("start", start).put("len", len))
        write(ctx, o)
    }

    fun clearFav(ctx: Context, ref: String) {
        val o = read(ctx)
        o.remove(ref)
        write(ctx, o)
    }

    fun exportJson(ctx: Context): String = read(ctx).toString()

    fun importJson(ctx: Context, raw: String, replace: Boolean) {
        val incoming = try { JSONObject(raw) } catch (e: Exception) { return }
        val base = if (replace) JSONObject() else read(ctx)
        incoming.keys().forEach { k -> base.put(k, incoming.get(k)) }
        write(ctx, base)
    }
}
