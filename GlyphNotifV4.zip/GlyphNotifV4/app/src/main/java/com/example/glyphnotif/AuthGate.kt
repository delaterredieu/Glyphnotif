package com.example.glyphnotif

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * Terrain préparé pour la V4.1 (règles masquées).
 * - Rule.hidden existe déjà et est sauvegardé ;
 * - Vault.unlocked décidera si les règles masquées sont visibles ;
 * - AuthGate demande l'empreinte / le visage / le code de l'écran de verrouillage.
 * Dans cette version, rien n'est masqué : Vault.unlocked reste vrai.
 */
object Vault {
    var unlocked by mutableStateOf(true)
}

fun List<Rule>.visibleRules(): List<Rule> = if (Vault.unlocked) this else filter { !it.hidden }

object AuthGate {
    private const val AUTH = BiometricManager.Authenticators.BIOMETRIC_STRONG or
        BiometricManager.Authenticators.DEVICE_CREDENTIAL

    fun statusLabel(ctx: Context): String = when (BiometricManager.from(ctx).canAuthenticate(AUTH)) {
        BiometricManager.BIOMETRIC_SUCCESS -> "Disponible"
        BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "Aucune empreinte ni code configuré"
        BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> "Pas de capteur"
        BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> "Capteur indisponible"
        else -> "Non disponible"
    }

    fun authenticate(activity: FragmentActivity, title: String, onResult: (Boolean) -> Unit) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                onResult(true)
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                onResult(false)
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setAllowedAuthenticators(AUTH)
            .build()
        prompt.authenticate(info)
    }
}
