package com.example.glyphnotif

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import java.util.zip.InflaterInputStream

// ====================================================================== motifs lumineux des glyphtones

/** Motif lumineux : une ligne par « image », une colonne par zone, valeurs 0..max. */
class GlyphTrack(val frames: List<IntArray>, val columns: Int, val max: Int) {
    fun durationMs(frameMs: Int): Long = frames.size.toLong() * frameMs
}

/** Lecture des tags (commentaires Vorbis / Opus) d'un fichier .ogg. */
object OggTags {
    fun read(b: ByteArray): Map<String, String> {
        val packets = ArrayList<ByteArray>()
        var cur = ByteArrayOutputStream()
        var pos = 0
        while (packets.size < 2 && pos + 27 <= b.size) {
            if (b[pos] != 'O'.code.toByte() || b[pos + 1] != 'g'.code.toByte() ||
                b[pos + 2] != 'g'.code.toByte() || b[pos + 3] != 'S'.code.toByte()
            ) break
            val segCount = b[pos + 26].toInt() and 0xFF
            val tableStart = pos + 27
            if (tableStart + segCount > b.size) break
            val dataPos = tableStart + segCount
            var total = 0
            for (i in 0 until segCount) total += b[tableStart + i].toInt() and 0xFF
            var p = dataPos
            for (i in 0 until segCount) {
                val len = b[tableStart + i].toInt() and 0xFF
                if (p + len > b.size) return emptyMap()
                cur.write(b, p, len)
                p += len
                if (len < 255) {
                    packets.add(cur.toByteArray())
                    cur = ByteArrayOutputStream()
                    if (packets.size >= 2) break
                }
            }
            pos = dataPos + total
        }
        if (packets.size < 2) return emptyMap()
        val pkt = packets[1]
        var off = when {
            pkt.size > 7 && pkt[0].toInt() == 3 && String(pkt, 1, 6, Charsets.US_ASCII) == "vorbis" -> 7
            pkt.size > 8 && String(pkt, 0, 8, Charsets.US_ASCII) == "OpusTags" -> 8
            else -> return emptyMap()
        }
        fun u32(): Int {
            val v = (pkt[off].toInt() and 0xFF) or ((pkt[off + 1].toInt() and 0xFF) shl 8) or
                ((pkt[off + 2].toInt() and 0xFF) shl 16) or ((pkt[off + 3].toInt() and 0xFF) shl 24)
            off += 4
            return v
        }
        val vendor = u32()
        off += vendor
        val count = u32()
        val out = LinkedHashMap<String, String>()
        for (i in 0 until count) {
            if (off + 4 > pkt.size) break
            val len = u32()
            if (len < 0 || off + len > pkt.size) break
            val s = String(pkt, off, len, Charsets.UTF_8)
            off += len
            val eq = s.indexOf('=')
            if (eq > 0) out[s.substring(0, eq).uppercase()] = s.substring(eq + 1)
        }
        return out
    }
}

/**
 * Glyphtone : fichier audio dont le motif lumineux est stocké dans le tag AUTHOR
 * (CSV compressé en Zlib puis encodé en Base64).
 * ATTENTION : format décrit d'après la documentation communautaire, jamais testé ici.
 * L'écran Sons > Diagnostic permet de voir ce qui est réellement lu.
 */
object Glyphtone {
    // Hypothèse pour 5 colonnes : A, B, C, D, E
    private val ZONES5 = listOf(
        listOf(0), listOf(1), listOf(2, 3, 4, 5), listOf(7, 8, 9, 10, 11, 12, 13, 14), listOf(6)
    )
    // Hypothèse pour 15 colonnes : A1, B1, C1..C4, D1..D8, E1
    private val MAP15 = intArrayOf(0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 6)

    fun parse(bytes: ByteArray): Pair<GlyphTrack?, String> {
        val sb = StringBuilder()
        val tags = try {
            OggTags.read(bytes)
        } catch (e: Exception) {
            sb.append("Lecture des tags impossible : ${e.message}\n")
            emptyMap()
        }
        val isOgg = bytes.size >= 4 && String(bytes, 0, 4, Charsets.US_ASCII) == "OggS"
        sb.append("Octets lus : ${bytes.size} · fichier Ogg : ${if (isOgg) "oui" else "non"}\n")
        sb.append("Tags (nom et longueur) : ")
            .append(if (tags.isEmpty()) "aucun" else tags.entries.joinToString { "${it.key}(${it.value.length})" })
            .append('\n')
        val raw = tags["AUTHOR"]
        if (raw == null) {
            sb.append("Pas de tag AUTHOR : pas de motif lumineux dans ce fichier.\n")
            return null to sb.toString()
        }
        val csv = try {
            val z = Base64.decode(raw.trim(), Base64.DEFAULT)
            InflaterInputStream(ByteArrayInputStream(z)).readBytes().toString(Charsets.UTF_8)
        } catch (e: Exception) {
            sb.append("Décodage Base64/Zlib impossible : ${e.message}\n")
            sb.append("Début du tag : ${raw.take(60)}\n")
            return null to sb.toString()
        }
        val rows = csv.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }
            .map { line -> line.split(',').mapNotNull { it.trim().toDoubleOrNull()?.toInt() }.toIntArray() }
            .filter { it.isNotEmpty() }.toList()
        if (rows.isEmpty()) {
            sb.append("CSV vide ou illisible.\nDébut : ${csv.take(120)}\n")
            return null to sb.toString()
        }
        val cols = rows.groupBy { it.size }.maxByOrNull { it.value.size }!!.key
        val frames = rows.filter { it.size == cols }
        val max = frames.maxOf { r -> r.max() }
        sb.append("Lignes : ${frames.size} · colonnes : $cols · valeur max : $max\n")
        sb.append("Premières lignes :\n")
        frames.take(3).forEach { sb.append(it.joinToString(",")).append('\n') }
        return GlyphTrack(frames, cols, max) to sb.toString()
    }

    fun ledsFor(row: IntArray, columns: Int, thr: Int): Set<Int> {
        val out = HashSet<Int>()
        when (columns) {
            5 -> ZONES5.forEachIndexed { z, leds -> if (row.getOrElse(z) { 0 } > thr) out.addAll(leds) }
            15 -> row.forEachIndexed { c, v -> if (v > thr && c < MAP15.size) out.add(MAP15[c]) }
            else -> row.forEachIndexed { c, v ->
                if (v > thr) out.add((c * ZONE_COUNT / columns).coerceIn(0, ZONE_COUNT - 1))
            }
        }
        return out
    }
}

// ====================================================================== bibliothèque de sons

data class SoundItem(val id: String, val name: String, val file: String, val glyph: Boolean)

object SoundLibrary {
    var items by mutableStateOf<List<SoundItem>>(emptyList())
        private set

    private val tracks = HashMap<String, GlyphTrack?>()

    fun dir(ctx: Context): File = File(ctx.filesDir, "sounds").also { it.mkdirs() }
    fun indexFile(ctx: Context): File = File(ctx.filesDir, "sounds.json")
    fun fileOf(ctx: Context, item: SoundItem): File = File(dir(ctx), item.file)

    fun load(ctx: Context) {
        items = readIndex(ctx)
    }

    fun parseIndex(raw: String): List<SoundItem> = try {
        val a = JSONArray(raw)
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            SoundItem(o.getString("id"), o.optString("name"), File(o.getString("file")).name, o.optBoolean("glyph", false))
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun readIndex(ctx: Context): List<SoundItem> {
        val f = indexFile(ctx)
        return if (f.exists()) parseIndex(f.readText()) else emptyList()
    }

    private fun writeIndex(ctx: Context, list: List<SoundItem>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("file", it.file).put("glyph", it.glyph))
        }
        indexFile(ctx).writeText(a.toString())
    }

    /** Copie un fichier audio choisi par l'utilisateur dans la bibliothèque (hors thread principal). */
    fun importFrom(ctx: Context, uri: Uri): SoundItem? {
        val cr = ctx.contentResolver
        var display = "Son"
        cr.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) display = c.getString(i) ?: display
        }
        val ext = display.substringAfterLast('.', "ogg").lowercase().filter { it.isLetterOrDigit() }.ifEmpty { "ogg" }
        val id = UUID.randomUUID().toString().take(8)
        val out = File(dir(ctx), "$id.$ext")
        try {
            val ins = cr.openInputStream(uri) ?: return null
            ins.use { input -> out.outputStream().use { input.copyTo(it) } }
        } catch (e: Exception) {
            out.delete()
            return null
        }
        val glyph = if (out.length() < 30_000_000L) {
            try { Glyphtone.parse(out.readBytes()).first != null } catch (e: Exception) { false }
        } else false
        val item = SoundItem(id, display.substringBeforeLast('.'), out.name, glyph)
        val list = readIndex(ctx) + item
        writeIndex(ctx, list)
        items = list
        return item
    }

    fun rename(ctx: Context, id: String, name: String) {
        val list = readIndex(ctx).map { if (it.id == id) it.copy(name = name) else it }
        writeIndex(ctx, list)
        items = list
    }

    fun delete(ctx: Context, id: String) {
        val all = readIndex(ctx)
        all.firstOrNull { it.id == id }?.let { fileOf(ctx, it).delete() }
        val list = all.filter { it.id != id }
        writeIndex(ctx, list)
        items = list
        synchronized(tracks) { tracks.remove("lib:$id") }
    }

    /** Restauration depuis une sauvegarde. */
    fun restore(ctx: Context, incoming: List<SoundItem>, srcDir: File, replace: Boolean) {
        var list = if (replace) {
            dir(ctx).listFiles()?.forEach { it.delete() }
            emptyList()
        } else readIndex(ctx)
        incoming.forEach { s ->
            if (list.none { it.id == s.id }) {
                val f = File(srcDir, s.file)
                if (f.exists()) {
                    f.copyTo(File(dir(ctx), s.file), overwrite = true)
                    list = list + s
                }
            }
        }
        writeIndex(ctx, list)
        items = list
        synchronized(tracks) { tracks.clear() }
    }

    fun uriFor(ctx: Context, ref: String): Uri? = when {
        ref.startsWith("lib:") -> items.firstOrNull { it.id == ref.removePrefix("lib:") }?.let { Uri.fromFile(fileOf(ctx, it)) }
        ref.startsWith("sys:") -> Uri.parse(ref.removePrefix("sys:"))
        else -> null
    }

    fun nameFor(ctx: Context, ref: String): String = when {
        ref.isEmpty() -> "Aucun"
        ref.startsWith("lib:") -> items.firstOrNull { it.id == ref.removePrefix("lib:") }?.name ?: "Son supprimé"
        ref.startsWith("sys:") -> try {
            RingtoneManager.getRingtone(ctx, Uri.parse(ref.removePrefix("sys:")))?.getTitle(ctx) ?: "Son du téléphone"
        } catch (e: Exception) {
            "Son du téléphone"
        }
        else -> "Aucun"
    }

    fun hasGlyph(ref: String): Boolean =
        ref.startsWith("lib:") && items.firstOrNull { it.id == ref.removePrefix("lib:") }?.glyph == true

    /** Lit les premiers octets d'un son (bibliothèque ou téléphone). Le motif lumineux est dans l'en-tête du fichier. */
    private fun readBytesFor(ctx: Context, ref: String): ByteArray? {
        return try {
            when {
                ref.startsWith("lib:") -> {
                    val item = items.firstOrNull { it.id == ref.removePrefix("lib:") } ?: return null
                    fileOf(ctx, item).readBytes()
                }
                ref.startsWith("sys:") -> {
                    val ins = ctx.contentResolver.openInputStream(Uri.parse(ref.removePrefix("sys:"))) ?: return null
                    ins.use { input ->
                        val out = ByteArrayOutputStream()
                        val buf = ByteArray(64 * 1024)
                        var total = 0
                        while (total < 3_000_000) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            total += n
                        }
                        out.toByteArray()
                    }
                }
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Motif lumineux d'un son (bibliothèque "lib:" ou téléphone "sys:"), null s'il n'y en a pas. Hors thread principal. */
    fun glyphTrack(ctx: Context, ref: String): GlyphTrack? {
        if (ref.isEmpty()) return null
        synchronized(tracks) { if (tracks.containsKey(ref)) return tracks[ref] }
        val bytes = readBytesFor(ctx, ref)
        val t = if (bytes == null) null else try { Glyphtone.parse(bytes).first } catch (e: Exception) { null }
        synchronized(tracks) { tracks[ref] = t }
        return t
    }

    fun diagnostic(ctx: Context, ref: String): String {
        val bytes = readBytesFor(ctx, ref) ?: return "Impossible de lire ce son."
        val source = if (ref.startsWith("sys:")) "son du téléphone" else "bibliothèque"
        val body = try { Glyphtone.parse(bytes).second } catch (e: Exception) { "Erreur : ${e.message}" }
        return "Source : $source\n$body"
    }

    private val durations = HashMap<String, Int>()

    /** Durée d'un son en millisecondes (0 si inconnue). Hors thread principal. */
    fun durationMs(ctx: Context, ref: String): Int {
        synchronized(durations) { durations[ref]?.let { return it } }
        val uri = uriFor(ctx, ref) ?: return 0
        val d = try {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toIntOrNull() ?: 0
            } finally {
                r.release()
            }
        } catch (e: Exception) {
            0
        }
        if (d > 0) synchronized(durations) { durations[ref] = d }
        return d
    }

    /** Extrait réellement joué pour une règle : (début en ms, durée en ms ; 0 = jusqu'à la fin). Hors thread principal. */
    fun segment(ctx: Context, rule: Rule): Pair<Int, Int> {
        val total = durationMs(ctx, rule.sound)
        return when (rule.soundSpan) {
            SoundSpan.FULL -> 0 to total
            SoundSpan.FAVORITE -> {
                val fav = SoundMeta.getFav(ctx, rule.sound)
                if (fav == null) 0 to total else fav.first to (if (total > 0) minOf(fav.second, (total - fav.first).coerceAtLeast(1)) else fav.second)
            }
            SoundSpan.CUSTOM -> {
                val start = if (total > 0) rule.soundStartMs.coerceIn(0, (total - 1).coerceAtLeast(0)) else rule.soundStartMs.coerceAtLeast(0)
                val len = if (total > 0) minOf(rule.soundLenMs.coerceAtLeast(100), (total - start).coerceAtLeast(1)) else rule.soundLenMs.coerceAtLeast(100)
                start to len
            }
        }
    }

    /** Sons présents sur le téléphone (sonneries, notifications, alarmes) : (titre, uri). */
    fun systemSounds(ctx: Context): List<Pair<String, String>> = try {
        val rm = RingtoneManager(ctx)
        rm.setType(RingtoneManager.TYPE_RINGTONE or RingtoneManager.TYPE_NOTIFICATION or RingtoneManager.TYPE_ALARM)
        val c = rm.cursor
        val out = ArrayList<Pair<String, String>>()
        while (c.moveToNext()) {
            out.add(c.getString(RingtoneManager.TITLE_COLUMN_INDEX) to rm.getRingtoneUri(c.position).toString())
        }
        out
    } catch (e: Exception) {
        emptyList()
    }
}

// ====================================================================== lecture

object SoundPlayer {
    /** Référence du son en cours d'aperçu (ou null). */
    var playingId by mutableStateOf<String?>(null)
        private set

    private var preview: MediaPlayer? = null
    private var previewStart = 0
    private var previewLen = 0
    private var ruleMp: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    private fun make(
        ctx: Context, uri: Uri, usage: Int, contentType: Int, vol: Float, startMs: Int, onDone: (MediaPlayer) -> Unit
    ): MediaPlayer? {
        val mp = MediaPlayer()
        return try {
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(usage).setContentType(contentType).build())
            mp.setDataSource(ctx, uri)
            mp.setVolume(vol, vol)
            mp.setOnCompletionListener { onDone(it) }
            mp.setOnErrorListener { p, _, _ -> onDone(p); true }
            mp.prepare()
            if (startMs > 0) {
                mp.setOnSeekCompleteListener { it.start() }
                mp.seekTo(startMs.toLong(), MediaPlayer.SEEK_CLOSEST)
            } else {
                mp.start()
            }
            mp
        } catch (e: Exception) {
            try { mp.release() } catch (_: Exception) {}
            null
        }
    }

    // ---- aperçu (écran Sons, éditeur d'un son, sélecteur de son)

    /** Lance ou arrête l'aperçu. startMs / lenMs : n'écouter qu'un extrait (lenMs = 0 : jusqu'à la fin). */
    @Synchronized
    fun togglePreview(ctx: Context, id: String, uri: Uri?, startMs: Int = 0, lenMs: Int = 0) {
        if (playingId == id) {
            stopPreview()
            return
        }
        stopPreview()
        if (uri == null) return
        val mp = make(ctx.applicationContext, uri, AudioAttributes.USAGE_MEDIA, AudioAttributes.CONTENT_TYPE_MUSIC, 1f, startMs) { done ->
            synchronized(this) {
                if (preview === done) {
                    try { done.release() } catch (_: Exception) {}
                    preview = null
                    playingId = null
                }
            }
        } ?: return
        preview = mp
        previewStart = startMs
        previewLen = lenMs
        playingId = id
        if (lenMs > 0) {
            handler.postDelayed({
                synchronized(this) { if (preview === mp) stopPreview() }
            }, lenMs.toLong())
        }
    }

    @Synchronized
    fun stopPreview() {
        preview?.let {
            try { it.stop() } catch (_: Exception) {}
            try { it.release() } catch (_: Exception) {}
        }
        preview = null
        playingId = null
    }

    @Synchronized
    fun previewProgress(): Float = try {
        val p = preview
        if (p == null) 0f
        else if (previewLen > 0) ((p.currentPosition - previewStart).toFloat() / previewLen).coerceIn(0f, 1f)
        else if (p.duration > 0) p.currentPosition.toFloat() / p.duration
        else 0f
    } catch (e: Exception) {
        0f
    }

    // ---- son d'une règle

    private val ruleToken = Any()

    /**
     * Joue le son d'une règle à partir de startMs. Si cutAfterMs > 0, le lecteur coupe lui-même le son après ce délai :
     * la coupure ne dépend donc plus de la durée de la lumière ni de la vie de la règle.
     * Renvoie false si rien n'a été joué (mode silencieux, son introuvable…).
     */
    fun playRule(ctx: Context, rule: Rule, startMs: Int = 0, cutAfterMs: Int = 0): Boolean {
        val uri = SoundLibrary.uriFor(ctx, rule.sound) ?: return false
        if (rule.respectSilent) {
            val am = ctx.getSystemService(AudioManager::class.java)
            if (am != null && am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return false
        }
        synchronized(this) {
            stopRuleLocked()
            val mp = make(
                ctx.applicationContext, uri, AudioAttributes.USAGE_NOTIFICATION,
                AudioAttributes.CONTENT_TYPE_SONIFICATION, rule.soundVolume / 100f, startMs
            ) { done ->
                synchronized(this) {
                    if (ruleMp === done) {
                        try { done.release() } catch (_: Exception) {}
                        ruleMp = null
                    }
                }
            }
            ruleMp = mp
            if (mp != null && cutAfterMs > 0) {
                handler.postDelayed({
                    synchronized(this) { if (ruleMp === mp) stopRuleLocked() }
                }, ruleToken, cutAfterMs.toLong())
            }
            return mp != null
        }
    }

    @Synchronized
    fun stopRule() {
        stopRuleLocked()
    }

    private fun stopRuleLocked() {
        handler.removeCallbacksAndMessages(ruleToken)
        ruleMp?.let {
            try { it.stop() } catch (_: Exception) {}
            try { it.release() } catch (_: Exception) {}
        }
        ruleMp = null
    }
}
