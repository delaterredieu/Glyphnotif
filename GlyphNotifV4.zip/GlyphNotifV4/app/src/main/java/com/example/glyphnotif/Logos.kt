package com.example.glyphnotif

data class LogoDef(val name: String, val res: Int)

/** Banque de logos (une entrée de manifeste existe pour chaque lettre : IconA, IconB, ...). */
val LOGOS: List<LogoDef> = listOf(
    LogoDef("Anneau", R.mipmap.ic_launcher_a),
    LogoDef("Barres", R.mipmap.ic_launcher_b),
    LogoDef("Diagonale", R.mipmap.ic_launcher_c),
    LogoDef("Matrice", R.mipmap.ic_launcher_d),
    LogoDef("Nothing clair", R.mipmap.ic_launcher_e),
    LogoDef("Glyph", R.mipmap.ic_launcher_f),
    LogoDef("Batterie", R.mipmap.ic_launcher_g),
    LogoDef("Cadran", R.mipmap.ic_launcher_h),
    LogoDef("Cloche", R.mipmap.ic_launcher_i),
    LogoDef("Éclair", R.mipmap.ic_launcher_j),
    LogoDef("Étoile", R.mipmap.ic_launcher_k),
    LogoDef("Ampoule", R.mipmap.ic_launcher_l),
    LogoDef("Vagues", R.mipmap.ic_launcher_m),
    LogoDef("Cible", R.mipmap.ic_launcher_n),
    LogoDef("Cœur", R.mipmap.ic_launcher_o),
    LogoDef("Œil", R.mipmap.ic_launcher_p)
)
