package com.example.glyphnotif

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

/**
 * Nothing Phone (1) : 15 canaux, indices 0..14 :
 * 0 = A1, 1 = B1, 2-5 = C1..C4, 6 = E1, 7-14 = D1_1..D1_8 (barre de batterie).
 */
const val ZONE_COUNT = 15
val ZONE_LABELS: List<String> = listOf(
    "A1", "B1", "C1", "C2", "C3", "C4", "E1",
    "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8"
)
val ALL_LEDS: Set<Int> = (0 until ZONE_COUNT).toSet()

enum class Mode(val label: String) {
    STATIC("Fixe"),
    BLINK("Clignotement"),
    BREATHE("Respiration (animation du SDK)"),
    CHASE("Parcours (une LED après l'autre)"),
    TONE("Motif du son (glyphtone)")
}

/** Durée de la lumière : durée fixe, jusqu'à fermeture de la notification, ou infini tant que non vue. */
enum class Persist(val label: String) {
    TIMED("Durée"),
    UNTIL_REMOVED("Jusqu'à fermeture"),
    INFINITE("Infini")
}

/** Quelle partie du son est jouée. */
enum class SoundSpan(val label: String) {
    FULL("Son entier"),
    FAVORITE("Passage favori"),
    CUSTOM("Extrait perso")
}

/** Lien entre la durée du son et celle de la lumière. */
enum class SoundTiming(val label: String) {
    INDEPENDENT("Indépendants"),
    CUT_WITH_LIGHT("Son coupé"),
    LIGHT_FOLLOWS("Lumière = son")
}

/** Catégories standard Android (Notification.category). */
val CATEGORIES: List<Pair<String, String>> = listOf(
    "" to "Toutes les catégories",
    "msg" to "Message / SMS",
    "email" to "E-mail",
    "call" to "Appel",
    "social" to "Réseau social",
    "reminder" to "Rappel",
    "event" to "Événement",
    "alarm" to "Alarme",
    "promo" to "Promotion",
    "progress" to "Progression",
    "status" to "Statut"
)

data class Rule(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Nouvelle règle",
    val enabled: Boolean = true,
    val pkg: String = "",              // vide = toutes les applis
    val titleContains: String = "",    // contacts (titre de la notif), séparés par des retours à la ligne ; vide = tous
    val textContains: String = "",     // mot-clé dans le texte ; vide = tous
    val category: String = "",         // catégorie Android ; vide = toutes
    val channelId: String = "",        // type de notification propre à l'appli (canal Android) ; vide = tous
    val channelName: String = "",
    val leds: Set<Int> = emptySet(),
    val mode: Mode = Mode.BREATHE,
    val periodMs: Int = 1000,
    val persist: Persist = Persist.TIMED,
    val durationMs: Int = 10_000,      // utilisé seulement si persist == TIMED
    val stopOnRemoval: Boolean = true, // TIMED : s'arrêter si la notification est fermée / ouverte
    val stopOnScreenOn: Boolean = false,
    val stopOnUnlock: Boolean = false,
    val sound: String = "",            // "" = aucun, "lib:<id>" = bibliothèque, "sys:<uri>" = son du téléphone
    val soundVolume: Int = 80,
    val soundRepeatSec: Int = 0,       // pause entre deux lectures ; 0 = ne pas répéter
    val respectSilent: Boolean = true,
    val soundSpan: SoundSpan = SoundSpan.FULL,
    val soundStartMs: Int = 0,         // extrait perso : début
    val soundLenMs: Int = 3000,        // extrait perso : durée
    val soundTiming: SoundTiming = SoundTiming.INDEPENDENT,
    val hidden: Boolean = false        // préparé pour la V4.1 (règles masquées) ; aucune interface pour l'instant
)

fun Rule.contacts(): List<String> = titleContains.split('\n').map { it.trim() }.filter { it.isNotEmpty() }

fun Rule.matches(pkgName: String, title: String, text: String, cat: String, channel: String): Boolean {
    if (!enabled || !(leds.isNotEmpty() || mode == Mode.TONE)) return false
    if (pkg.isNotEmpty() && pkg != pkgName) return false
    if (category.isNotEmpty() && category != cat) return false
    if (channelId.isNotEmpty() && channelId != channel) return false
    val cs = contacts()
    if (cs.isNotEmpty() && cs.none { title.contains(it, ignoreCase = true) }) return false
    if (textContains.isNotBlank() && !text.contains(textContains.trim(), ignoreCase = true)) return false
    return true
}

fun fmtDur(ms: Int): String = when {
    ms < 1000 -> "$ms ms"
    ms % 1000 == 0 -> "${ms / 1000} s"
    else -> String.format(Locale.getDefault(), "%.1f s", ms / 1000.0)
}

/** Instant dans un son : m:ss.d */
fun fmtTime(ms: Int): String =
    String.format(Locale.getDefault(), "%d:%02d.%d", ms / 60000, (ms / 1000) % 60, (ms % 1000) / 100)

fun Rule.persistSummary(): String = when (persist) {
    Persist.TIMED -> fmtDur(durationMs)
    Persist.UNTIL_REMOVED -> "jusqu'à fermeture"
    Persist.INFINITE -> "infini"
}

data class Preset(val name: String, val leds: Set<Int>, val mode: Mode, val periodMs: Int)

/** Motifs prédéfinis (créés pour cette appli, pas les motifs officiels Nothing). */
val PRESETS = listOf(
    Preset("Tout · respiration lente", ALL_LEDS, Mode.BREATHE, 2000),
    Preset("Tout · clignotement rapide", ALL_LEDS, Mode.BLINK, 400),
    Preset("Parcours complet", ALL_LEDS, Mode.CHASE, 1200),
    Preset("Une LED sur deux · fixe", ALL_LEDS.filter { it % 2 == 0 }.toSet(), Mode.STATIC, 1000),
    Preset("4 premières · pulsation", (0..3).toSet(), Mode.BREATHE, 1000)
)

fun Rule.toJson(): JSONObject = JSONObject().apply {
    put("id", id); put("name", name); put("enabled", enabled); put("pkg", pkg)
    put("title", titleContains); put("text", textContains); put("category", category)
    put("channelId", channelId); put("channelName", channelName)
    put("leds", JSONArray(leds.toList()))
    put("mode", mode.name); put("period", periodMs)
    put("persist", persist.name); put("durationMs", durationMs)
    put("stopRemoval", stopOnRemoval); put("stopScreenOn", stopOnScreenOn); put("stopUnlock", stopOnUnlock)
    put("sound", sound); put("soundVol", soundVolume); put("soundRepeat", soundRepeatSec); put("respectSilent", respectSilent)
    put("soundSpan", soundSpan.name); put("soundStart", soundStartMs); put("soundLen", soundLenMs)
    put("soundTiming", soundTiming.name)
    put("hidden", hidden)
}

/** Lit une règle, y compris celles enregistrées par les versions précédentes (V1 à V3). */
fun JSONObject.toRule(): Rule {
    val arr = optJSONArray("leds") ?: JSONArray()
    val legacySec = optInt("duration", 10)
    val persist = if (has("persist")) {
        runCatching { Persist.valueOf(optString("persist")) }.getOrDefault(Persist.TIMED)
    } else if (legacySec == 0) Persist.UNTIL_REMOVED else Persist.TIMED
    val durMs = if (has("durationMs")) optInt("durationMs", 10_000) else if (legacySec <= 0) 10_000 else legacySec * 1000
    return Rule(
        id = optString("id", UUID.randomUUID().toString()),
        name = optString("name"),
        enabled = optBoolean("enabled", true),
        pkg = optString("pkg"),
        titleContains = optString("title"),
        textContains = optString("text"),
        category = optString("category"),
        channelId = optString("channelId"),
        channelName = optString("channelName"),
        leds = (0 until arr.length()).map { arr.getInt(it) }.toSet(),
        mode = runCatching { Mode.valueOf(optString("mode")) }.getOrDefault(Mode.BREATHE),
        periodMs = optInt("period", 1000),
        persist = persist,
        durationMs = durMs.coerceAtLeast(100),
        stopOnRemoval = optBoolean("stopRemoval", true),
        stopOnScreenOn = optBoolean("stopScreenOn", false),
        stopOnUnlock = optBoolean("stopUnlock", false),
        sound = optString("sound"),
        soundVolume = optInt("soundVol", 80),
        soundRepeatSec = optInt("soundRepeat", 0),
        respectSilent = optBoolean("respectSilent", true),
        soundSpan = runCatching { SoundSpan.valueOf(optString("soundSpan")) }.getOrDefault(SoundSpan.FULL),
        soundStartMs = optInt("soundStart", 0),
        soundLenMs = optInt("soundLen", 3000),
        soundTiming = runCatching { SoundTiming.valueOf(optString("soundTiming")) }.getOrDefault(SoundTiming.INDEPENDENT),
        hidden = optBoolean("hidden", false)
    )
}

object RuleStore {
    private const val PREFS = "rules"
    private const val KEY = "list"
    private const val KEY_TEMPLATE = "template"

    fun parse(raw: String): List<Rule> = try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { arr.getJSONObject(it).toRule() }
    } catch (e: Exception) {
        emptyList()
    }

    fun toJsonArray(rules: List<Rule>): JSONArray {
        val arr = JSONArray()
        rules.forEach { arr.put(it.toJson()) }
        return arr
    }

    fun load(ctx: Context): List<Rule> =
        parse(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]")

    fun save(ctx: Context, rules: List<Rule>) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, toJsonArray(rules).toString()).apply()
    }

    /** Valeurs par défaut des nouvelles règles. */
    fun loadTemplate(ctx: Context): Rule {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TEMPLATE, null)
        // identifiant fixe : l'éditeur ne doit pas se réinitialiser à chaque rafraîchissement de l'écran
        return (raw?.let { runCatching { JSONObject(it).toRule() }.getOrNull() }
            ?: Rule(leds = ALL_LEDS, mode = Mode.BREATHE, periodMs = 2000)).copy(id = "template")
    }

    fun saveTemplate(ctx: Context, r: Rule) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_TEMPLATE, r.toJson().toString()).apply()
    }

    fun newRule(ctx: Context): Rule = loadTemplate(ctx).copy(
        id = UUID.randomUUID().toString(), name = "Nouvelle règle", enabled = true, hidden = false,
        pkg = "", titleContains = "", textContains = "", category = "", channelId = "", channelName = ""
    )
}
