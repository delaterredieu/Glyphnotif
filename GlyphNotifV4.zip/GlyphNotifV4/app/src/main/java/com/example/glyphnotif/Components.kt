package com.example.glyphnotif

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// ------------------------------------------------------------------ données utilitaires

data class AppInfo(val pkg: String, val label: String)

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun appLabel(ctx: Context, pkg: String): String = try {
    val pm = ctx.packageManager
    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
} catch (e: Exception) {
    pkg
}

object IconCache {
    private val map = java.util.concurrent.ConcurrentHashMap<String, ImageBitmap>()
    fun peek(pkg: String): ImageBitmap? = map[pkg]
    fun load(ctx: Context, pkg: String): ImageBitmap? = map[pkg] ?: try {
        ctx.packageManager.getApplicationIcon(pkg).toBitmap(128, 128).asImageBitmap().also { map[pkg] = it }
    } catch (e: Exception) {
        null
    }
}

/** Compteur incrémenté à chaque retour dans l'appli : permet de rafraîchir les états (permissions, Glyph…). */
object AppState {
    var resumeTick by mutableIntStateOf(0)
}

// ------------------------------------------------------------------ page type "iOS"

/** Page avec grand titre. [onBack] affiche « ‹ backLabel » en haut à gauche. */
@Composable
fun Page(
    title: String,
    backLabel: String? = null,
    onBack: (() -> Unit)? = null,
    trailing: @Composable () -> Unit = {},
    titleLeading: (@Composable () -> Unit)? = null,
    bottomSpace: Dp = 32.dp,
    fab: @Composable BoxScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    val p = LocalPalette.current
    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp).padding(bottom = bottomSpace)
        ) {
            Row(
                Modifier.fillMaxWidth().height(48.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (onBack != null) {
                    Text(
                        "‹ ${backLabel ?: "Retour"}", color = p.accent, fontSize = 17.sp,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onBack).padding(vertical = 8.dp, horizontal = 4.dp)
                    )
                } else {
                    Spacer(Modifier.width(1.dp))
                }
                trailing()
            }
            Row(Modifier.padding(top = 4.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                if (titleLeading != null) {
                    titleLeading()
                    Spacer(Modifier.width(12.dp))
                }
                Text(title, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            }
            content()
        }
        fab()
    }
}

@Composable
fun GroupCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().card(), content = content)
}

@Composable
fun Separator() {
    val p = LocalPalette.current
    Box(Modifier.fillMaxWidth().padding(start = 16.dp).height(0.5.dp).background(p.separator))
}

@Composable
fun SectionHeader(t: String) {
    Text(
        t.uppercase(), fontSize = 13.sp, color = LocalPalette.current.secondary,
        modifier = Modifier.padding(start = 16.dp, top = 20.dp, bottom = 6.dp)
    )
}

@Composable
fun SectionFooter(t: String) {
    Text(t, fontSize = 13.sp, color = LocalPalette.current.secondary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
}

// ------------------------------------------------------------------ lignes

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RowItem(
    title: String,
    subtitle: String? = null,
    leading: (@Composable () -> Unit)? = null,
    trailing: @Composable () -> Unit = {},
    titleColor: Color = Color.Unspecified,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null
) {
    val p = LocalPalette.current
    val vPad = when (AppSettings.density) {
        0 -> 7.dp
        2 -> 17.dp
        else -> 12.dp
    }
    val click = if (onClick != null || onLongClick != null) {
        Modifier.combinedClickable(onClick = { onClick?.invoke() }, onLongClick = onLongClick)
    } else {
        Modifier
    }
    Row(
        Modifier.fillMaxWidth().then(click).padding(horizontal = 16.dp, vertical = vPad),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leading != null) {
            leading()
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 17.sp, color = if (titleColor == Color.Unspecified) p.text else titleColor)
            if (subtitle != null) {
                Text(subtitle, fontSize = 13.sp, color = p.secondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        trailing()
    }
}

/** Ligne avec chevron « › » (ouvre une sous-page ou un choix). */
@Composable
fun NavRow(title: String, value: String? = null, leading: (@Composable () -> Unit)? = null, onClick: () -> Unit) {
    val p = LocalPalette.current
    RowItem(title, leading = leading, onClick = onClick, trailing = {
        if (value != null) {
            Text(value, fontSize = 17.sp, color = p.secondary, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 190.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text("›", fontSize = 22.sp, color = p.secondary)
    })
}

/** Ligne d'action (texte coloré). */
@Composable
fun ActionRow(title: String, color: Color = Color.Unspecified, onClick: () -> Unit) {
    val p = LocalPalette.current
    RowItem(title, titleColor = if (color == Color.Unspecified) p.accent else color, onClick = onClick)
}

@Composable
fun AppSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    Switch(
        checked, onChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White, checkedTrackColor = p.accent, checkedBorderColor = Color.Transparent,
            uncheckedThumbColor = Color.White, uncheckedTrackColor = p.chip, uncheckedBorderColor = Color.Transparent
        )
    )
}

@Composable
fun SwitchRow(title: String, subtitle: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    RowItem(title, subtitle, onClick = { onChange(!checked) }, trailing = { AppSwitch(checked, onChange) })
}

/** Pictogramme monochrome (style réglages Android). */
@Composable
fun SettingIcon(icon: ImageVector) {
    val p = LocalPalette.current
    Icon(icon, null, Modifier.size(24.dp), tint = p.text.copy(alpha = 0.75f))
}

/** Pastille « toutes les applis » (cloche monochrome). */
@Composable
fun AllAppsIcon(size: Dp = 36.dp) {
    val p = LocalPalette.current
    Box(Modifier.size(size).clip(RoundedCornerShape(size * 0.225f)).background(p.chip), contentAlignment = Alignment.Center) {
        Icon(Icons.Outlined.Notifications, null, Modifier.size(size * 0.6f), tint = p.text.copy(alpha = 0.75f))
    }
}

@Composable
fun FieldRow(label: String, value: String, placeholder: String, onChange: (String) -> Unit) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 17.sp, modifier = Modifier.width(96.dp))
        BasicTextField(
            value, onChange,
            singleLine = true,
            textStyle = TextStyle(color = p.text, fontSize = 17.sp),
            cursorBrush = SolidColor(p.accent),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) Text(placeholder, color = p.secondary, fontSize = 17.sp)
                    inner()
                }
            }
        )
    }
}

@Composable
fun DropdownRow(title: String, options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val label = options.firstOrNull { it.first == selected }?.second ?: selected
    Box {
        NavRow(title, value = label) { open = true }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (value, text) ->
                DropdownMenuItem(text = { Text(text) }, onClick = { onSelect(value); open = false })
            }
        }
    }
}

@Composable
fun SliderRow(title: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    val p = LocalPalette.current
    Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, fontSize = 17.sp)
            Text(valueText, fontSize = 17.sp, color = p.secondary)
        }
        Slider(value, onChange, valueRange = range)
    }
}

/** Trois curseurs rouge / vert / bleu pour une couleur personnalisée (argb = entier ARGB). */
@Composable
fun ColorSliders(argb: Int, onChange: (Int) -> Unit) {
    val r = (argb shr 16) and 0xFF
    val g = (argb shr 8) and 0xFF
    val b = argb and 0xFF
    fun mk(r: Int, g: Int, b: Int): Int = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    Column {
        Box(Modifier.fillMaxWidth().padding(16.dp).height(28.dp).clip(RoundedCornerShape(8.dp)).background(Color(argb)))
        SliderRow("Rouge", "$r", r.toFloat(), 0f..255f) { onChange(mk(it.toInt(), g, b)) }
        SliderRow("Vert", "$g", g.toFloat(), 0f..255f) { onChange(mk(r, it.toInt(), b)) }
        SliderRow("Bleu", "$b", b.toFloat(), 0f..255f) { onChange(mk(r, g, it.toInt())) }
    }
}

/** Pastille de couleur sélectionnable (label optionnel affiché au centre). */
@Composable
fun Swatch(color: Color, label: String?, selected: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        Modifier.size(38.dp).clip(CircleShape).background(color)
            .border(if (selected) 3.dp else 1.dp, if (selected) p.text.copy(alpha = 0.6f) else p.separator, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (selected) Text("✓", color = if (color.luminance() > 0.6f) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        else if (label != null) Text(label, color = p.text, fontSize = 14.sp)
    }
}


// ------------------------------------------------------------------ boutons

@Composable
fun FilledAction(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        modifier.clip(RoundedCornerShape(12.dp)).background(p.accent).clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun TintedAction(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        modifier.clip(RoundedCornerShape(12.dp)).background(p.chip).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Trois points verticaux (accès aux réglages). */
@Composable
fun DotsButton(onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Column(verticalArrangement = Arrangement.spacedBy(3.5.dp)) {
            repeat(3) { Box(Modifier.size(5.dp).background(p.accent, CircleShape)) }
        }
    }
}

/** Bouton rond « + » en bas (à droite, ou à gauche selon le réglage). */
@Composable
fun BoxScope.AddFab(onClick: () -> Unit) {
    val p = LocalPalette.current
    val fill: Brush = if (p.glass) {
        Brush.linearGradient(listOf(p.accent.copy(alpha = 0.95f), p.accent.copy(alpha = 0.60f)))
    } else {
        SolidColor(p.accent)
    }
    Box(
        Modifier.align(if (AppSettings.fabLeft) Alignment.BottomStart else Alignment.BottomEnd)
            .navigationBarsPadding().padding(20.dp).size(60.dp)
            .then(if (p.glass) Modifier else Modifier.shadow(6.dp, CircleShape))
            .clip(CircleShape).background(fill, CircleShape)
            .then(if (p.glass) Modifier.border(1.dp, Color.White.copy(alpha = 0.7f), CircleShape) else Modifier)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text("+", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.chip).padding(2.dp)) {
        options.forEachIndexed { i, o ->
            val on = i == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                    .background(if (on) p.card else Color.Transparent)
                    .clickable { onSelect(i) }.padding(vertical = 8.dp, horizontal = 2.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(o, fontSize = 13.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

// ------------------------------------------------------------------ icônes

@Composable
fun AppIcon(pkg: String, size: Dp = 36.dp) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    var bmp by remember(pkg) { mutableStateOf(IconCache.peek(pkg)) }
    LaunchedEffect(pkg) {
        if (bmp == null) bmp = withContext(Dispatchers.Default) { IconCache.load(ctx, pkg) }
    }
    val shape = RoundedCornerShape(size * 0.225f)
    val b = bmp
    if (b != null) {
        Image(b, null, Modifier.size(size).clip(shape))
    } else {
        Box(Modifier.size(size).clip(shape).background(p.chip))
    }
}

/** Aperçu d'un logo de la banque (icône adaptative du lanceur). */
@Composable
fun LauncherPreview(res: Int, size: Dp = 44.dp, selected: Boolean = false) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val bmp = remember(res) { ContextCompat.getDrawable(ctx, res)?.toBitmap(160, 160)?.asImageBitmap() }
    val shape = RoundedCornerShape(size * 0.24f)
    val mod = Modifier.size(size).clip(shape).then(if (selected) Modifier.border(3.dp, p.accent, shape) else Modifier)
    if (bmp != null) Image(bmp, null, mod) else Spacer(mod)
}

/** Miniature d'une image enregistrée (logo personnalisé). */
@Composable
fun FileThumb(path: String, size: Dp = 44.dp) {
    val bmp = remember(path) { BitmapFactory.decodeFile(path)?.asImageBitmap() }
    val shape = RoundedCornerShape(size * 0.24f)
    if (bmp != null) Image(bmp, null, Modifier.size(size).clip(shape)) else Spacer(Modifier.size(size))
}

// ------------------------------------------------------------------ boîtes de dialogue

@Composable
fun TextInputDialog(title: String, initial: String, onOk: (String) -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton({ onOk(v.trim()) }) { Text("OK", color = p.accent) } },
        dismissButton = { TextButton(onDismiss) { Text("Annuler", color = p.accent) } },
        title = { Text(title) },
        text = {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.chip).padding(12.dp)) {
                BasicTextField(
                    v, { v = it }, singleLine = true,
                    textStyle = TextStyle(color = p.text, fontSize = 16.sp),
                    cursorBrush = SolidColor(p.accent)
                )
            }
        }
    )
}

// ------------------------------------------------------------------ sons

@Composable
fun PlayButton(playing: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(Modifier.size(38.dp).clip(CircleShape).background(p.chip).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(if (playing) Icons.Outlined.Pause else Icons.Outlined.PlayArrow, null, Modifier.size(24.dp), tint = p.accent)
    }
}

/** Ligne de son avec bouton lecture/pause et barre de progression pendant l'aperçu. */
@Composable
fun SoundRow(
    title: String,
    subtitle: String?,
    ref: String,
    onPlay: () -> Unit,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit = {}
) {
    val p = LocalPalette.current
    val playing = SoundPlayer.playingId == ref
    var progress by remember { mutableStateOf(0f) }
    LaunchedEffect(playing) {
        while (playing) {
            progress = SoundPlayer.previewProgress()
            delay(100)
        }
        progress = 0f
    }
    Column {
        RowItem(title, subtitle, leading = { PlayButton(playing, onPlay) }, trailing = trailing, onClick = onClick)
        if (playing) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 8.dp),
                color = p.accent,
                trackColor = p.chip
            )
        }
    }
}
