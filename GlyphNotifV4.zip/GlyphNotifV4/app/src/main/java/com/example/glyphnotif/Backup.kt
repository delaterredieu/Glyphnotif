package com.example.glyphnotif

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Sauvegarde : un seul fichier .glyphbackup (archive zip) contenant
 * manifest.json (version du format), rules.json, template.json, settings.json,
 * sounds.json + dossier sounds, background.jpg, dossier logos (images PNG)
 */
object Backup {
    const val VERSION = 1
    private const val MAX_BYTES = 400L * 1024 * 1024

    class Result(val ok: Boolean, val message: String)

    private fun settingsJson(ctx: Context): JSONObject {
        val o = JSONObject()
        ctx.getSharedPreferences(AppSettings.PREFS, Context.MODE_PRIVATE).all.forEach { (k, v) ->
            if (v != null) o.put(k, v)
        }
        return o
    }

    /** Écrit la sauvegarde dans le fichier choisi par l'utilisateur (hors thread principal). */
    fun write(ctx: Context, uri: Uri): Result = try {
        val os = ctx.contentResolver.openOutputStream(uri) ?: return Result(false, "Impossible d'écrire le fichier.")
        os.use { out ->
            ZipOutputStream(out.buffered()).use { zip ->
                fun putBytes(name: String, bytes: ByteArray) {
                    zip.putNextEntry(ZipEntry(name)); zip.write(bytes); zip.closeEntry()
                }
                fun putFile(name: String, f: File) {
                    zip.putNextEntry(ZipEntry(name)); f.inputStream().use { it.copyTo(zip) }; zip.closeEntry()
                }
                putBytes(
                    "manifest.json",
                    JSONObject().put("format", "glyphnotif-backup").put("version", VERSION)
                        .put("created", System.currentTimeMillis()).toString().toByteArray()
                )
                putBytes("rules.json", RuleStore.toJsonArray(RuleStore.load(ctx)).toString().toByteArray())
                putBytes("template.json", RuleStore.loadTemplate(ctx).toJson().toString().toByteArray())
                putBytes("settings.json", settingsJson(ctx).toString().toByteArray())
                putBytes("soundmeta.json", SoundMeta.exportJson(ctx).toByteArray())
                val idx = SoundLibrary.indexFile(ctx)
                if (idx.exists()) putFile("sounds.json", idx)
                SoundLibrary.items.forEach {
                    val f = SoundLibrary.fileOf(ctx, it)
                    if (f.exists()) putFile("sounds/${f.name}", f)
                }
                val bg = Media.bgFile(ctx)
                if (bg.exists()) putFile("background.jpg", bg)
                Media.logoFiles(ctx).forEach { putFile("logos/${it.name}", it) }
            }
        }
        Result(true, "Sauvegarde créée : ${RuleStore.load(ctx).size} règle(s), ${SoundLibrary.items.size} son(s).")
    } catch (e: Exception) {
        Result(false, "Échec de la sauvegarde : ${e.message}")
    }

    /** Restaure depuis un fichier .glyphbackup. replace = true remplace tout, sinon ajoute aux règles existantes. */
    fun restore(ctx: Context, uri: Uri, replace: Boolean): Result {
        val tmp = File(ctx.cacheDir, "restore")
        return try {
            tmp.deleteRecursively()
            File(tmp, "sounds").mkdirs()
            File(tmp, "logos").mkdirs()
            val ins = ctx.contentResolver.openInputStream(uri) ?: return Result(false, "Impossible de lire le fichier.")
            var total = 0L
            ins.use { raw ->
                ZipInputStream(raw.buffered()).use { zip ->
                    var e: ZipEntry? = zip.nextEntry
                    while (e != null) {
                        val name = e.name
                        val target: File? = when {
                            e.isDirectory -> null
                            name == "manifest.json" || name == "rules.json" || name == "template.json" ||
                                name == "settings.json" || name == "sounds.json" || name == "soundmeta.json" ||
                                name == "background.jpg" -> File(tmp, name)
                            name.startsWith("sounds/") -> File(File(tmp, "sounds"), File(name).name)
                            name.startsWith("logos/") -> File(File(tmp, "logos"), File(name).name)
                            else -> null
                        }
                        if (target != null) {
                            target.outputStream().use { out ->
                                val buf = ByteArray(64 * 1024)
                                while (true) {
                                    val n = zip.read(buf)
                                    if (n < 0) break
                                    total += n
                                    if (total > MAX_BYTES) throw IllegalStateException("fichier trop volumineux")
                                    out.write(buf, 0, n)
                                }
                            }
                        }
                        zip.closeEntry()
                        e = zip.nextEntry
                    }
                }
            }

            val manifestFile = File(tmp, "manifest.json")
            if (!manifestFile.exists()) return Result(false, "Ce fichier n'est pas une sauvegarde GlyphNotif.")
            val manifest = JSONObject(manifestFile.readText())
            if (manifest.optString("format") != "glyphnotif-backup") return Result(false, "Ce fichier n'est pas une sauvegarde GlyphNotif.")
            val version = manifest.optInt("version", 0)
            if (version > VERSION) {
                return Result(false, "Cette sauvegarde a été créée par une version plus récente de l'appli (format $version). Mets l'appli à jour.")
            }

            // --- règles
            val rulesFile = File(tmp, "rules.json")
            var added = 0
            if (rulesFile.exists()) {
                val incoming = RuleStore.parse(rulesFile.readText())
                val merged = if (replace) incoming else {
                    val existing = RuleStore.load(ctx)
                    val ids = existing.map { it.id }.toMutableSet()
                    existing + incoming.map {
                        if (it.id in ids) it.copy(id = UUID.randomUUID().toString()) else it
                    }.onEach { ids.add(it.id) }
                }
                added = incoming.size
                RuleStore.save(ctx, merged)
            }

            // --- sons
            val soundsFile = File(tmp, "sounds.json")
            var sounds = 0
            if (soundsFile.exists()) {
                val items = SoundLibrary.parseIndex(soundsFile.readText())
                SoundLibrary.restore(ctx, items, File(tmp, "sounds"), replace)
                sounds = items.size
            } else if (replace) {
                SoundLibrary.restore(ctx, emptyList(), File(tmp, "sounds"), true)
            }

            File(tmp, "soundmeta.json").takeIf { it.exists() }?.let {
                runCatching { SoundMeta.importJson(ctx, it.readText(), replace) }
            }

            // --- images
            File(tmp, "logos").listFiles()?.forEach { f ->
                val dest = File(Media.logoDir(ctx), f.name)
                if (replace || !dest.exists()) f.copyTo(dest, overwrite = true)
            }

            // --- réglages d'apparence (seulement en mode « remplacer »)
            if (replace) {
                File(tmp, "template.json").takeIf { it.exists() }?.let {
                    runCatching { RuleStore.saveTemplate(ctx, JSONObject(it.readText()).toRule()) }
                }
                File(tmp, "settings.json").takeIf { it.exists() }?.let { sf ->
                    val o = JSONObject(sf.readText())
                    val ed = ctx.getSharedPreferences(AppSettings.PREFS, Context.MODE_PRIVATE).edit()
                    val floatKeys = setOf("textScale", "bgDim")
                    o.keys().forEach { k ->
                        val v = o.get(k)
                        when {
                            k in floatKeys && v is Number -> ed.putFloat(k, v.toFloat())
                            v is Boolean -> ed.putBoolean(k, v)
                            v is Number -> ed.putInt(k, v.toInt())
                            v is String -> ed.putString(k, v)
                            else -> {}
                        }
                    }
                    ed.apply()
                    AppSettings.load(ctx)
                }
                val bg = File(tmp, "background.jpg")
                if (bg.exists()) {
                    bg.copyTo(Media.bgFile(ctx), overwrite = true)
                } else {
                    Media.bgFile(ctx).delete()
                }
                AppSettings.bgImageVersion += 1
            }

            tmp.deleteRecursively()
            Result(true, "Restauration terminée : $added règle(s), $sounds son(s).")
        } catch (e: Exception) {
            tmp.deleteRecursively()
            Result(false, "Échec de la restauration : ${e.message}")
        }
    }
}
