package com.example.glyphnotif

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Backup as BackupIcon
import androidx.compose.material.icons.outlined.Image as ImageIcon
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ====================================================================== RÉGLAGES (menu)

@Composable
fun SettingsRoot(onBack: () -> Unit, onOpen: (Dest) -> Unit) {
    Page(title = "Réglages", backLabel = "Règles", onBack = onBack) {
        GroupCard {
            NavRow("Autorisations", leading = { SettingIcon(Icons.Outlined.Security) }) { onOpen(Dest.Permissions) }
            Separator()
            NavRow("Glyph", leading = { SettingIcon(Icons.Outlined.Lightbulb) }) { onOpen(Dest.GlyphSettings) }
            Separator()
            NavRow("Sons", leading = { SettingIcon(Icons.Outlined.MusicNote) }) { onOpen(Dest.Sounds) }
        }
        Spacer(Modifier.height(16.dp))
        GroupCard {
            NavRow("Apparence", leading = { SettingIcon(Icons.Outlined.Palette) }) { onOpen(Dest.Appearance) }
            Separator()
            NavRow("Fond d'écran", leading = { SettingIcon(Icons.Outlined.ImageIcon) }) { onOpen(Dest.Background) }
            Separator()
            NavRow("Logo de l'appli", leading = { SettingIcon(Icons.Outlined.Apps) }) { onOpen(Dest.Logo) }
        }
        Spacer(Modifier.height(16.dp))
        GroupCard {
            NavRow("Valeurs par défaut", leading = { SettingIcon(Icons.Outlined.Tune) }) { onOpen(Dest.Defaults) }
            Separator()
            NavRow("Sauvegarde et restauration", leading = { SettingIcon(Icons.Outlined.BackupIcon) }) { onOpen(Dest.Backup) }
            Separator()
            NavRow("Sécurité", leading = { SettingIcon(Icons.Outlined.Lock) }) { onOpen(Dest.Security) }
        }
        SectionFooter("GlyphNotif V4")
    }
}

// ====================================================================== AUTORISATIONS

@Composable
fun PermissionsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val tick = AppState.resumeTick
    val listenerOn = remember(tick) { NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName) }

    Page(title = "Autorisations", backLabel = "Réglages", onBack = onBack) {
        SectionHeader("Notifications")
        GroupCard {
            NavRow("Accès aux notifications", value = if (listenerOn) "Activé" else "Désactivé") {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        SectionFooter("Indispensable : sans cet accès, l'appli ne voit ni les notifications ni les SMS.")

        SectionHeader("Si l'interrupteur est grisé")
        GroupCard {
            NavRow("Autoriser les paramètres restreints") {
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            }
        }
        SectionFooter("Dans les infos de l'appli, ouvre le menu ⋮ en haut à droite puis choisis « Autoriser les paramètres restreints ».")

        SectionHeader("Batterie")
        GroupCard {
            NavRow("Optimisation de la batterie") {
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        SectionFooter("Choisis « Ne pas optimiser » pour GlyphNotif afin qu'Android ne coupe pas l'appli en arrière-plan.")
    }
}

// ====================================================================== GLYPH

@Composable
fun GlyphScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    var refresh by remember { mutableIntStateOf(0) }
    val tick = AppState.resumeTick
    val ready = remember(refresh, tick) { GlyphController.ready }
    val canWrite = remember(refresh, tick) { GlyphDev.canWrite(ctx) }
    val devOn = remember(refresh, tick) { GlyphDev.isEnabled(ctx) }
    val last = remember(refresh, tick) { GlyphDev.lastRenewMs(ctx) }
    var note by remember { mutableStateOf<String?>(null) }

    Page(title = "Glyph", backLabel = "Réglages", onBack = onBack) {
        SectionHeader("État")
        GroupCard {
            RowItem("Session Glyph", trailing = {
                Text(if (ready) "Prête" else "Non connectée", fontSize = 17.sp, color = if (ready) Green else p.secondary)
            })
            Separator()
            ActionRow("Actualiser") { refresh++ }
        }

        SectionHeader("Tests")
        GroupCard {
            ActionRow("Tout allumer 2 s") {
                GlyphController.play(Rule(leds = ALL_LEDS, mode = Mode.STATIC, durationMs = 2000), null)
            }
            Separator()
            ActionRow("Éteindre la Glyph") { GlyphController.stopAll() }
        }

        SectionHeader("Mode développeur Glyph")
        GroupCard {
            RowItem("Mode développeur", trailing = {
                Text(if (devOn) "Activé" else "Désactivé", fontSize = 17.sp, color = if (devOn) Green else p.secondary)
            })
            Separator()
            RowItem("Réactivation automatique", trailing = {
                Text(if (canWrite) "Autorisée" else "Non autorisée", fontSize = 17.sp, color = if (canWrite) Green else p.secondary)
            })
            Separator()
            RowItem("Dernière réactivation", trailing = {
                Text(
                    if (last > 0L) SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(last)) else "jamais",
                    fontSize = 17.sp, color = p.secondary
                )
            })
            Separator()
            ActionRow("Réactiver maintenant") {
                if (!canWrite) {
                    note = "Autorisation manquante : lance une seule fois la commande indiquée ci-dessous."
                } else {
                    val ok = GlyphDev.enable(ctx, restart = true)
                    if (ok) GlyphController.reconnect(ctx)
                    note = if (ok) "Mode développeur réactivé." else "Échec de la réactivation."
                    refresh++
                }
            }
        }
        if (note != null) SectionFooter(note!!)
        SectionFooter("Le mode développeur du SDK s'éteint tout seul au bout de 48 h. Pour ne plus taper la commande à chaque fois, accorde UNE FOIS cette autorisation à l'appli (téléphone branché en USB) :")
        GroupCard {
            Text(
                "adb shell pm grant com.example.glyphnotif android.permission.WRITE_SECURE_SETTINGS",
                fontFamily = FontFamily.Monospace, fontSize = 13.sp,
                modifier = Modifier.padding(16.dp)
            )
        }
        SectionFooter("Ensuite, l'appli réactive le mode toute seule : au démarrage, à chaque ouverture et toutes les 6 h. L'autorisation disparaît si tu désinstalles l'appli. En attendant, ou en secours, la commande manuelle reste : adb shell settings put global nt_glyph_interface_debug_enable 1")
    }
}

// ====================================================================== SONS

@Composable
fun SoundsScreen(onBack: () -> Unit, onOpenSound: (String) -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val scope = rememberCoroutineScope()
    val system = remember { SoundLibrary.systemSounds(ctx) }
    var q by remember { mutableStateOf("") }
    var lightPreview by remember { mutableStateOf(true) }
    var importMsg by remember { mutableStateOf<String?>(null) }

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val item = withContext(Dispatchers.IO) { SoundLibrary.importFrom(ctx, uri) }
            importMsg = if (item == null) "Import impossible." else if (item.glyph) "« ${item.name} » importé (motif lumineux détecté)." else "« ${item.name} » importé."
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            SoundPlayer.stopPreview()
            GlyphController.stopPreviewLight()
        }
    }

    fun toggle(ref: String) {
        val wasPlaying = SoundPlayer.playingId == ref
        GlyphController.stopPreviewLight()
        SoundPlayer.togglePreview(ctx, ref, SoundLibrary.uriFor(ctx, ref))
        if (!wasPlaying && lightPreview) {
            scope.launch {
                val t = withContext(Dispatchers.IO) { SoundLibrary.glyphTrack(ctx, ref) }
                if (t != null && SoundPlayer.playingId == ref) GlyphController.previewTrack(t)
            }
        }
    }

    val libItems = SoundLibrary.items.filter { q.isBlank() || it.name.contains(q, ignoreCase = true) }
    val sysItems = system.filter { q.isBlank() || it.first.contains(q, ignoreCase = true) }

    Page(title = "Sons", backLabel = "Réglages", onBack = onBack) {
        SearchField(q, { q = it }, "Rechercher un son")

        SectionHeader("Ma bibliothèque")
        GroupCard {
            if (libItems.isEmpty()) {
                Text(
                    if (SoundLibrary.items.isEmpty()) "Aucun son importé." else "Aucun résultat.",
                    color = p.secondary, fontSize = 16.sp,
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                )
                Separator()
            }
            libItems.forEach { s ->
                val ref = "lib:${s.id}"
                val fav = SoundMeta.getFav(ctx, ref)
                val sub = listOfNotNull(
                    if (s.glyph) "Glyphtone" else null,
                    fav?.let { "Favori ${fmtTime(it.first)}" }
                ).joinToString(" · ").ifEmpty { null }
                SoundRow(
                    title = s.name, subtitle = sub, ref = ref,
                    onPlay = { toggle(ref) }, onClick = { onOpenSound(ref) },
                    trailing = { Text("›", fontSize = 22.sp, color = p.secondary) }
                )
                Separator()
            }
            ActionRow("Importer un son…") { importer.launch(arrayOf("audio/*", "application/ogg", "application/octet-stream")) }
        }
        if (importMsg != null) SectionFooter(importMsg!!)
        SectionFooter("Importe des fichiers audio (.ogg, .mp3, .wav…) ou des glyphtones Nothing téléchargés. Je ne fournis aucun son : utilise uniquement des fichiers dont tu as le droit de te servir. Touche un son pour régler son extrait, son passage favori ou voir son diagnostic.")

        SectionHeader("Sons du téléphone")
        GroupCard {
            if (sysItems.isEmpty()) {
                Text(
                    "Aucun son trouvé.", color = p.secondary, fontSize = 16.sp,
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                )
            }
            sysItems.forEachIndexed { i, (name, uri) ->
                if (i > 0) Separator()
                val ref = "sys:$uri"
                val fav = SoundMeta.getFav(ctx, ref)
                SoundRow(
                    title = name, subtitle = fav?.let { "Favori ${fmtTime(it.first)}" }, ref = ref,
                    onPlay = { toggle(ref) }, onClick = { onOpenSound(ref) },
                    trailing = { Text("›", fontSize = 22.sp, color = p.secondary) }
                )
            }
        }

        SectionHeader("Motifs lumineux (glyphtones)")
        GroupCard {
            SwitchRow("Aperçu lumineux avec le son", "La Glyph joue le motif du son pendant l'aperçu, s'il en contient un", lightPreview) { lightPreview = it }
            Separator()
            SliderRow("Durée d'une ligne du motif", "${AppSettings.toneFrameMs} ms", AppSettings.toneFrameMs.toFloat(), 4f..80f) {
                AppSettings.edit(ctx) { toneFrameMs = it.toInt().coerceAtLeast(1) }
            }
            Separator()
            SliderRow("Seuil d'allumage", "${AppSettings.toneThreshold} %", AppSettings.toneThreshold.toFloat(), 5f..90f) {
                AppSettings.edit(ctx) { toneThreshold = it.toInt() }
            }
        }
        SectionFooter("La Glyph du Phone (1) s'allume ou s'éteint, sans intensité : le seuil règle à partir de quel niveau une zone s'allume. Si la lumière est décalée par rapport au son, ajuste la durée d'une ligne.")
    }
}

// ====================================================================== UN SON (extrait, favori, diagnostic)

@Composable
fun SoundEditorScreen(ref: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val scope = rememberCoroutineScope()
    var total by remember { mutableIntStateOf(0) }
    var start by remember { mutableIntStateOf(0) }
    var len by remember { mutableIntStateOf(3000) }
    var fav by remember { mutableStateOf(SoundMeta.getFav(ctx, ref)) }
    var diag by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    val isLib = ref.startsWith("lib:")
    val name = SoundLibrary.nameFor(ctx, ref)
    val playing = SoundPlayer.playingId
    val maxT = if (total > 0) total else 600_000
    val step = if (maxT > 60_000) 1000 else 500

    LaunchedEffect(ref) {
        total = withContext(Dispatchers.IO) { SoundLibrary.durationMs(ctx, ref) }
        val f = fav
        if (f != null) {
            start = f.first
            len = f.second
        }
        if (total > 0 && len > total) len = total
    }
    LaunchedEffect(playing) {
        while (playing != null) {
            progress = SoundPlayer.previewProgress()
            delay(100)
        }
        progress = 0f
    }
    DisposableEffect(Unit) {
        onDispose {
            SoundPlayer.stopPreview()
            GlyphController.stopPreviewLight()
        }
    }

    fun play(id: String, s: Int, l: Int) {
        val wasPlaying = SoundPlayer.playingId == id
        GlyphController.stopPreviewLight()
        SoundPlayer.togglePreview(ctx, id, SoundLibrary.uriFor(ctx, ref), s, l)
        if (!wasPlaying) {
            scope.launch {
                val t = withContext(Dispatchers.IO) { SoundLibrary.glyphTrack(ctx, ref) }
                if (t != null && SoundPlayer.playingId == id) GlyphController.previewTrack(t, s, l)
            }
        }
    }

    Page(title = name, backLabel = "Sons", onBack = onBack) {
        SectionHeader("Écoute")
        GroupCard {
            Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledAction(if (playing == ref) "Arrêter" else "Écouter en entier") { play(ref, 0, 0) }
                TintedAction(if (playing == "$ref#clip") "Arrêter" else "Écouter l'extrait") { play("$ref#clip", start, len) }
            }
            if (playing != null) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 12.dp),
                    color = p.accent,
                    trackColor = p.chip
                )
            }
        }
        SectionFooter("Si le son contient un motif lumineux, la Glyph le joue pendant l'écoute.")

        SectionHeader("Extrait")
        GroupCard {
            RowItem("Durée du son", trailing = {
                Text(if (total > 0) fmtTime(total) else "inconnue", fontSize = 17.sp, color = p.secondary)
            })
            Separator()
            TimeSliderRow("Début de l'extrait", start, maxT, step) {
                start = it
                if (len > maxT - it) len = (maxT - it).coerceAtLeast(500)
            }
            Separator()
            TimeSliderRow("Durée de l'extrait", len, (maxT - start).coerceAtLeast(500), step) { len = it.coerceAtLeast(500) }
        }
        SectionFooter("Choisis n'importe quel passage du son, de la durée que tu veux. Dans une règle, tu pourras jouer le son en entier, ce passage favori, ou un extrait différent.")

        SectionHeader("Passage favori")
        GroupCard {
            val f = fav
            RowItem(if (f != null) "Favori : ${fmtTime(f.first)} · ${fmtDur(f.second)}" else "Aucun passage favori")
            Separator()
            ActionRow("Définir l'extrait ci-dessus comme favori") {
                SoundMeta.setFav(ctx, ref, start, len)
                fav = start to len
            }
            if (f != null) {
                Separator()
                ActionRow("Effacer le favori", color = Red) {
                    SoundMeta.clearFav(ctx, ref)
                    fav = null
                }
            }
        }

        SectionHeader("Motif lumineux")
        GroupCard { ActionRow("Diagnostic du motif") { diag = SoundLibrary.diagnostic(ctx, ref) } }
        SectionFooter("Indique si le fichier contient une lumière lisible (nombre de lignes et de colonnes). Utile pour vérifier un son Nothing.")

        if (isLib) {
            SectionHeader("Gérer")
            GroupCard {
                ActionRow("Renommer") { renaming = true }
                Separator()
                ActionRow("Supprimer ce son", color = Red) { confirmDelete = true }
            }
        }
    }

    diag?.let { text ->
        AlertDialog(
            onDismissRequest = { diag = null },
            confirmButton = { TextButton({ diag = null }) { Text("Fermer", color = p.accent) } },
            title = { Text("Diagnostic du motif") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(text, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                }
            }
        )
    }
    if (renaming) {
        TextInputDialog("Renommer le son", name, onOk = { n ->
            if (n.isNotBlank()) SoundLibrary.rename(ctx, ref.removePrefix("lib:"), n)
            renaming = false
        }, onDismiss = { renaming = false })
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer ce son ?") },
            text = { Text("Les règles qui l'utilisent n'auront plus de son.") },
            confirmButton = {
                TextButton({
                    confirmDelete = false
                    SoundPlayer.stopPreview()
                    SoundLibrary.delete(ctx, ref.removePrefix("lib:"))
                    onBack()
                }) { Text("Supprimer", color = Red) }
            },
            dismissButton = { TextButton({ confirmDelete = false }) { Text("Annuler", color = p.accent) } }
        )
    }
}

// ====================================================================== APPARENCE

@Composable
fun AppearanceScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current

    Page(title = "Apparence", backLabel = "Réglages", onBack = onBack) {
        SectionHeader("Thème")
        GroupCard {
            Box(Modifier.padding(12.dp)) {
                Segmented(listOf("Système", "Clair", "Sombre"), AppSettings.themeMode) { AppSettings.edit(ctx) { themeMode = it } }
            }
        }
        SectionFooter("« Système » suit le mode clair ou sombre du téléphone.")

        SectionHeader("Couleur des boutons")
        GroupCard {
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ACCENTS.forEachIndexed { i, (_, c) ->
                    Swatch(c, null, AppSettings.accentIndex == i) { AppSettings.edit(ctx) { accentIndex = i } }
                }
                Swatch(Color(AppSettings.accentCustom), "+", AppSettings.accentIndex == -1) { AppSettings.edit(ctx) { accentIndex = -1 } }
            }
            if (AppSettings.accentIndex == -1) {
                Separator()
                ColorSliders(AppSettings.accentCustom) { c -> AppSettings.edit(ctx) { accentCustom = c } }
            }
        }
        SectionFooter(
            "Couleur choisie : " + if (AppSettings.accentIndex in ACCENTS.indices) ACCENTS[AppSettings.accentIndex].first else "personnalisée"
        )

        SectionHeader("Cartes")
        GroupCard {
            Box(Modifier.padding(12.dp)) {
                Segmented(listOf("Solides", "Verre (Liquid Glass)"), if (AppSettings.glass) 1 else 0) { AppSettings.edit(ctx) { glass = it == 1 } }
            }
            Separator()
            SliderRow("Arrondi des coins", "${AppSettings.cornerRadius} dp", AppSettings.cornerRadius.toFloat(), 0f..28f) {
                AppSettings.edit(ctx) { cornerRadius = it.toInt() }
            }
        }
        SectionFooter("Le style Verre est une imitation de l'effet d'iOS : transparence et reflets, sans vrai flou de l'arrière-plan. Il se voit surtout avec un fond d'écran coloré (Réglages > Fond d'écran).")

        SectionHeader("Texte et liste")
        GroupCard {
            SliderRow("Taille du texte", "${(AppSettings.textScale * 100).toInt()} %", AppSettings.textScale, 0.8f..1.4f) {
                AppSettings.edit(ctx) { textScale = (Math.round(it * 20f) / 20f) }
            }
            Separator()
            Box(Modifier.padding(12.dp)) {
                Segmented(listOf("Compact", "Normal", "Aéré"), AppSettings.density) { AppSettings.edit(ctx) { density = it } }
            }
            Separator()
            SwitchRow("Logos des applis dans la liste", null, AppSettings.showAppIcons) { AppSettings.edit(ctx) { showAppIcons = it } }
            Separator()
            SwitchRow("Logo de l'appli en haut de l'accueil", null, AppSettings.showLogoInApp) { AppSettings.edit(ctx) { showLogoInApp = it } }
            Separator()
            SwitchRow("Bouton + à gauche", "Sinon il est en bas à droite", AppSettings.fabLeft) { AppSettings.edit(ctx) { fabLeft = it } }
            Separator()
            FieldRow("Titre", AppSettings.homeTitle, "Règles") { AppSettings.edit(ctx) { homeTitle = it } }
        }

        SectionHeader("Réinitialisation")
        GroupCard {
            ActionRow("Rétablir l'apparence d'origine", color = Red) {
                AppSettings.edit(ctx) {
                    themeMode = 0; accentIndex = 0; glass = false; cornerRadius = 16; textScale = 1f; density = 1
                    showAppIcons = true; showLogoInApp = false; fabLeft = false; homeTitle = "Règles"
                    bgMode = 0; bgColor = -1
                }
            }
        }
    }
}

// ====================================================================== FOND D'ÉCRAN

@Composable
fun BackgroundScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { Media.saveBackground(ctx, uri) }
            if (ok) AppSettings.edit(ctx) { bgMode = 2 }
        }
    }

    Page(title = "Fond d'écran", backLabel = "Réglages", onBack = onBack) {
        SectionHeader("Type de fond")
        GroupCard {
            Box(Modifier.padding(12.dp)) {
                Segmented(listOf("Uni", "Dégradé", "Image", "Taches"), AppSettings.bgMode) { AppSettings.edit(ctx) { bgMode = it } }
            }
        }

        when (AppSettings.bgMode) {
            0 -> {
                SectionHeader("Couleur")
                GroupCard {
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Swatch(p.bg, "A", AppSettings.bgColor == -1) { AppSettings.edit(ctx) { bgColor = -1 } }
                        BG_COLORS.forEachIndexed { i, c ->
                            Swatch(if (p.dark) c.dark else c.light, null, AppSettings.bgColor == i) { AppSettings.edit(ctx) { bgColor = i } }
                        }
                        Swatch(Color(AppSettings.bgCustom), "+", AppSettings.bgColor == -2) { AppSettings.edit(ctx) { bgColor = -2 } }
                    }
                    if (AppSettings.bgColor == -2) {
                        Separator()
                        ColorSliders(AppSettings.bgCustom) { c -> AppSettings.edit(ctx) { bgCustom = c } }
                    }
                }
                SectionFooter("« A » = automatique : blanc grisé en thème clair, noir en thème sombre. « + » = couleur de ton choix.")
            }
            1 -> {
                SectionHeader("Dégradé")
                GroupCard {
                    BG_GRADIENTS.forEachIndexed { i, g ->
                        if (i > 0) Separator()
                        RowItem(
                            g.first,
                            leading = {
                                Box(
                                    Modifier.size(36.dp).clip(RoundedCornerShape(8.dp))
                                        .background(Brush.verticalGradient(if (p.dark) g.third else g.second))
                                )
                            },
                            trailing = { if (AppSettings.bgGradient == i) Text("✓", color = p.accent, fontSize = 20.sp, fontWeight = FontWeight.Bold) },
                            onClick = { AppSettings.edit(ctx) { bgGradient = i } }
                        )
                    }
                }
            }
            2 -> {
                SectionHeader("Image")
                GroupCard {
                    ActionRow("Choisir une image de la galerie…") {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                    if (Media.bgFile(ctx).exists()) {
                        Separator()
                        SliderRow("Assombrissement", "${(AppSettings.bgDim * 100).toInt()} %", AppSettings.bgDim, 0f..0.8f) {
                            AppSettings.edit(ctx) { bgDim = it }
                        }
                        Separator()
                        SliderRow("Flou", "${AppSettings.bgBlur}", AppSettings.bgBlur.toFloat(), 0f..25f) {
                            AppSettings.edit(ctx) { bgBlur = it.toInt() }
                        }
                        Separator()
                        ActionRow("Retirer l'image", color = Red) { Media.removeBackground(ctx) }
                    }
                }
                SectionFooter("Pour garder les textes lisibles, augmente l'assombrissement ou passe les cartes en style Verre (Réglages > Apparence).")
            }
            else -> {
                SectionFooter("Fond coloré à taches lumineuses, qui suit la couleur des boutons.")
            }
        }
    }
}

// ====================================================================== LOGO

@Composable
fun LogoScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf(Media.logoFiles(ctx)) }
    var note by remember { mutableStateOf<String?>(null) }
    val pickLogo = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            withContext(Dispatchers.IO) { Media.saveLogo(ctx, uri) }
            files = Media.logoFiles(ctx)
        }
    }

    Page(title = "Logo de l'appli", backLabel = "Réglages", onBack = onBack) {
        SectionHeader("Banque de logos")
        GroupCard {
            Column(Modifier.padding(12.dp)) {
                LOGOS.chunked(4).forEachIndexed { rowIdx, row ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        row.forEachIndexed { c, logo ->
                            val idx = rowIdx * 4 + c
                            Column(
                                Modifier.weight(1f).clickable {
                                    IconSwitcher.apply(ctx, idx)
                                    AppSettings.edit(ctx) { logoIndex = idx }
                                },
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                LauncherPreview(logo.res, 56.dp, AppSettings.logoIndex == idx)
                                Text(logo.name, fontSize = 12.sp, color = p.secondary, maxLines = 1, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
        SectionFooter("Le lanceur peut mettre quelques secondes à afficher la nouvelle icône.")

        SectionHeader("Mes images")
        GroupCard {
            files.forEachIndexed { i, f ->
                RowItem(
                    "Image ${i + 1}",
                    leading = { FileThumb(f.path, 44.dp) },
                    trailing = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Épingler", color = p.accent, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable {
                                    note = if (Media.pinLogo(ctx, f)) null else "Ton lanceur ne permet pas d'épingler un raccourci."
                                }.padding(8.dp)
                            )
                            Text(
                                "✕", color = Red, fontSize = 18.sp,
                                modifier = Modifier.clip(CircleShape).clickable {
                                    f.delete(); files = Media.logoFiles(ctx)
                                }.padding(8.dp)
                            )
                        }
                    }
                )
                Separator()
            }
            ActionRow("Ajouter une image de la galerie…") {
                pickLogo.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
        }
        if (note != null) SectionFooter(note!!)
        SectionFooter("Android n'autorise pas à remplacer l'icône principale par une image libre : « Épingler » crée un raccourci sur l'écran d'accueil avec ton image (choisis une image dont le sujet est centré, les bords sont rognés). Pour une vraie icône personnalisée, il faut la remplacer dans Android Studio avant de compiler.")

        SectionHeader("Dans l'appli")
        GroupCard {
            SwitchRow("Afficher le logo en haut de l'accueil", null, AppSettings.showLogoInApp) { AppSettings.edit(ctx) { showLogoInApp = it } }
        }
    }
}

// ====================================================================== SAUVEGARDE

@Composable
fun BackupScreen(onBack: () -> Unit, onRestored: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<Uri?>(null) }

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) scope.launch {
            val res = withContext(Dispatchers.IO) { Backup.write(ctx, uri) }
            message = res.message
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pending = uri
    }

    fun restore(uri: Uri, replace: Boolean) {
        pending = null
        scope.launch {
            val res = withContext(Dispatchers.IO) { Backup.restore(ctx, uri, replace) }
            message = res.message
            if (res.ok) onRestored()
        }
    }

    Page(title = "Sauvegarde", backLabel = "Réglages", onBack = onBack) {
        SectionHeader("Contenu actuel")
        GroupCard {
            RowItem("Règles", trailing = { Text("${RuleStore.load(ctx).size}", color = p.secondary, fontSize = 17.sp) })
            Separator()
            RowItem("Sons importés", trailing = { Text("${SoundLibrary.items.size}", color = p.secondary, fontSize = 17.sp) })
        }

        SectionHeader("Sauvegarder")
        GroupCard {
            ActionRow("Créer une sauvegarde…") {
                val day = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                exporter.launch("glyphnotif-$day.glyphbackup")
            }
        }
        SectionFooter("Un seul fichier avec tes règles, tes réglages d'apparence, ton fond d'écran, tes logos et tes sons. Enregistre-le où tu veux (Téléchargements, Drive…) pour le garder ou le transmettre.")

        SectionHeader("Restaurer")
        GroupCard {
            ActionRow("Restaurer depuis un fichier…") { importer.launch(arrayOf("*/*")) }
        }
        SectionFooter("Les futures versions de l'appli sauront relire ce fichier. Tu choisis ensuite de tout remplacer, ou d'ajouter les règles à celles que tu as déjà.")
    }

    pending?.let { uri ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Restaurer la sauvegarde") },
            text = { Text("Remplacer tout (règles, apparence, sons, images) ou seulement ajouter les règles et les sons de la sauvegarde aux tiens ?") },
            confirmButton = {
                Row {
                    TextButton({ pending = null }) { Text("Annuler", color = p.accent) }
                    TextButton({ restore(uri, false) }) { Text("Ajouter", color = p.accent) }
                    TextButton({ restore(uri, true) }) { Text("Remplacer", color = Red) }
                }
            }
        )
    }
    message?.let { m ->
        AlertDialog(
            onDismissRequest = { message = null },
            confirmButton = { TextButton({ message = null }) { Text("OK", color = p.accent) } },
            text = { Text(m) }
        )
    }
}

// ====================================================================== SÉCURITÉ (terrain pour la V4.1)

@Composable
fun SecurityScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val activity = ctx as? FragmentActivity
    var result by remember { mutableStateOf<String?>(null) }
    val status = remember { AuthGate.statusLabel(ctx) }

    Page(title = "Sécurité", backLabel = "Réglages", onBack = onBack) {
        SectionHeader("Authentification")
        GroupCard {
            RowItem("État", trailing = { Text(status, fontSize = 17.sp, color = p.secondary) })
            Separator()
            ActionRow("Tester l'authentification") {
                if (activity != null) {
                    AuthGate.authenticate(activity, "Vérification") { ok ->
                        result = if (ok) "Authentification réussie." else "Authentification annulée ou refusée."
                    }
                }
            }
        }
        if (result != null) SectionFooter(result!!)
        SectionFooter("Prépare la future version 4.1 : des règles masquées, visibles uniquement après authentification (empreinte, visage ou code de l'écran de verrouillage). Rien n'est encore masqué dans cette version.")
    }
}
