package com.example.glyphnotif

import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File

/** Images de l'utilisateur : fond d'écran et logos personnalisés (copies privées dans l'appli). */
object Media {
    fun bgFile(ctx: Context) = File(ctx.filesDir, "background.jpg")
    fun logoDir(ctx: Context): File = File(ctx.filesDir, "logos").also { it.mkdirs() }
    fun logoFiles(ctx: Context): List<File> =
        logoDir(ctx).listFiles()?.filter { it.extension == "png" }?.sortedBy { it.name } ?: emptyList()

    private fun decode(ctx: Context, uri: Uri, maxSide: Int): Bitmap =
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { d, info, _ ->
            d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val w = info.size.width
            val h = info.size.height
            val s = maxOf(w, h)
            if (s > maxSide) {
                val f = maxSide.toFloat() / s
                d.setTargetSize((w * f).toInt().coerceAtLeast(1), (h * f).toInt().coerceAtLeast(1))
            }
        }

    fun saveBackground(ctx: Context, uri: Uri): Boolean = try {
        val b = decode(ctx, uri, 1600)
        bgFile(ctx).outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        AppSettings.bgImageVersion += 1
        true
    } catch (e: Exception) {
        false
    }

    fun removeBackground(ctx: Context) {
        bgFile(ctx).delete()
        AppSettings.bgImageVersion += 1
    }

    fun loadBackground(ctx: Context): ImageBitmap? = try {
        val f = bgFile(ctx)
        if (f.exists()) BitmapFactory.decodeFile(f.path)?.asImageBitmap() else null
    } catch (e: Exception) {
        null
    }

    /** Enregistre une image de la galerie comme logo (recadrée en carré). */
    fun saveLogo(ctx: Context, uri: Uri): File? = try {
        val src = decode(ctx, uri, 2048)
        val size = 432
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val side = minOf(src.width, src.height)
        val from = Rect((src.width - side) / 2, (src.height - side) / 2, (src.width + side) / 2, (src.height + side) / 2)
        Canvas(out).drawBitmap(src, from, Rect(0, 0, size, size), null)
        val f = File(logoDir(ctx), "logo_${System.currentTimeMillis()}.png")
        f.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
        f
    } catch (e: Exception) {
        null
    }

    /** Crée un raccourci sur l'écran d'accueil avec cette image (Android demande confirmation). */
    fun pinLogo(ctx: Context, file: File): Boolean {
        val sm = ctx.getSystemService(ShortcutManager::class.java) ?: return false
        if (!sm.isRequestPinShortcutSupported) return false
        val bmp = BitmapFactory.decodeFile(file.path) ?: return false
        val info = ShortcutInfo.Builder(ctx, "logo_${file.nameWithoutExtension}")
            .setShortLabel("GlyphNotif V4")
            .setIcon(Icon.createWithAdaptiveBitmap(bmp))
            .setIntent(Intent(ctx, MainActivity::class.java).setAction(Intent.ACTION_MAIN))
            .build()
        return sm.requestPinShortcut(info, null)
    }
}
