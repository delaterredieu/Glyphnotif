package com.example.glyphnotif

import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp

/** Couleurs proposées pour les boutons / éléments actifs. */
val ACCENTS: List<Pair<String, Color>> = listOf(
    "Bleu" to Color(0xFF007AFF),
    "Indigo" to Color(0xFF5856D6),
    "Violet" to Color(0xFFAF52DE),
    "Rose" to Color(0xFFFF2D55),
    "Rouge" to Color(0xFFFF3B30),
    "Orange" to Color(0xFFFF9500),
    "Vert" to Color(0xFF34C759),
    "Turquoise" to Color(0xFF30B0C7),
    "Graphite" to Color(0xFF636366)
)

data class BgColor(val name: String, val light: Color, val dark: Color)

/** Couleurs de fond unies (variante claire / sombre). */
val BG_COLORS: List<BgColor> = listOf(
    BgColor("Blanc / Noir", Color(0xFFFFFFFF), Color(0xFF000000)),
    BgColor("Gris", Color(0xFFE9E9EE), Color(0xFF1C1C1E)),
    BgColor("Bleu", Color(0xFFDCE9FF), Color(0xFF0B1B33)),
    BgColor("Vert", Color(0xFFDDF3E4), Color(0xFF0E2417)),
    BgColor("Rose", Color(0xFFFBE1EA), Color(0xFF2E1019)),
    BgColor("Sable", Color(0xFFF1E8D9), Color(0xFF2A2218)),
    BgColor("Lavande", Color(0xFFE8E1F7), Color(0xFF1D1530))
)

/** Dégradés : (nom, couleurs en thème clair, couleurs en thème sombre). */
val BG_GRADIENTS: List<Triple<String, List<Color>, List<Color>>> = listOf(
    Triple("Aube", listOf(Color(0xFFFFE3D0), Color(0xFFFFC2D8)), listOf(Color(0xFF2A1420), Color(0xFF3A1A2E))),
    Triple("Océan", listOf(Color(0xFFD6EEFF), Color(0xFFB9D4FF)), listOf(Color(0xFF07182B), Color(0xFF0E2B4D))),
    Triple("Forêt", listOf(Color(0xFFDDF5E3), Color(0xFFB8E3C8)), listOf(Color(0xFF08190F), Color(0xFF0F2E1C))),
    Triple("Crépuscule", listOf(Color(0xFFE6DDFB), Color(0xFFFBD9E6)), listOf(Color(0xFF150F2B), Color(0xFF2D1330)))
)

/** Réglages de l'appli, mémorisés sur le téléphone (tout est modifiable depuis les Réglages). */
object AppSettings {
    const val PREFS = "settings"

    /** 0 = suivre le téléphone, 1 = clair, 2 = sombre */
    var themeMode by mutableIntStateOf(0)
    /** index dans ACCENTS, ou -1 = couleur personnalisée */
    var accentIndex by mutableIntStateOf(0)
    var accentCustom by mutableIntStateOf(0xFF007AFF.toInt())
    /** Style des cartes : false = solide, true = verre */
    var glass by mutableStateOf(false)
    var logoIndex by mutableIntStateOf(0)
    var showLogoInApp by mutableStateOf(false)

    /** 0 = uni, 1 = dégradé, 2 = image, 3 = taches */
    var bgMode by mutableIntStateOf(0)
    /** -1 = automatique (selon le thème), -2 = personnalisée, sinon index dans BG_COLORS */
    var bgColor by mutableIntStateOf(-1)
    var bgCustom by mutableIntStateOf(0xFFF2F2F7.toInt())
    var bgGradient by mutableIntStateOf(0)
    var bgImageVersion by mutableIntStateOf(0)
    var bgDim by mutableFloatStateOf(0.25f)
    var bgBlur by mutableIntStateOf(0)

    var cornerRadius by mutableIntStateOf(16)
    var textScale by mutableFloatStateOf(1f)
    /** 0 = compact, 1 = normal, 2 = aéré */
    var density by mutableIntStateOf(1)
    var showAppIcons by mutableStateOf(true)
    var fabLeft by mutableStateOf(false)
    var homeTitle by mutableStateOf("Règles")

    /** Durée d'une ligne du motif d'un glyphtone (ms) et seuil d'allumage (% du maximum). */
    var toneFrameMs by mutableIntStateOf(16)
    var toneThreshold by mutableIntStateOf(33)

    val accentColor: Color
        get() = if (accentIndex in ACCENTS.indices) ACCENTS[accentIndex].second else Color(accentCustom)

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        themeMode = p.getInt("theme", 0).coerceIn(0, 2)
        accentIndex = p.getInt("accent", 0)
        accentCustom = p.getInt("accentCustom", 0xFF007AFF.toInt())
        glass = p.getBoolean("glass", false)
        logoIndex = p.getInt("logo", 0)
        showLogoInApp = p.getBoolean("showLogo", false)
        bgMode = p.getInt("bgMode", 0).coerceIn(0, 3)
        bgColor = p.getInt("bgColor", -1)
        bgCustom = p.getInt("bgCustom", 0xFFF2F2F7.toInt())
        bgGradient = p.getInt("bgGradient", 0)
        bgDim = p.getFloat("bgDim", 0.25f)
        bgBlur = p.getInt("bgBlur", 0)
        cornerRadius = p.getInt("corner", 16)
        textScale = p.getFloat("textScale", 1f)
        density = p.getInt("density", 1).coerceIn(0, 2)
        showAppIcons = p.getBoolean("showAppIcons", true)
        fabLeft = p.getBoolean("fabLeft", false)
        homeTitle = p.getString("homeTitle", "Règles") ?: "Règles"
        toneFrameMs = p.getInt("toneFrameMs", 16)
        toneThreshold = p.getInt("toneThreshold", 33)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("theme", themeMode)
            .putInt("accent", accentIndex)
            .putInt("accentCustom", accentCustom)
            .putBoolean("glass", glass)
            .putInt("logo", logoIndex)
            .putBoolean("showLogo", showLogoInApp)
            .putInt("bgMode", bgMode)
            .putInt("bgColor", bgColor)
            .putInt("bgCustom", bgCustom)
            .putInt("bgGradient", bgGradient)
            .putFloat("bgDim", bgDim)
            .putInt("bgBlur", bgBlur)
            .putInt("corner", cornerRadius)
            .putFloat("textScale", textScale)
            .putInt("density", density)
            .putBoolean("showAppIcons", showAppIcons)
            .putBoolean("fabLeft", fabLeft)
            .putString("homeTitle", homeTitle)
            .putInt("toneFrameMs", toneFrameMs)
            .putInt("toneThreshold", toneThreshold)
            .apply()
    }

    /** Modifie un ou plusieurs réglages puis les enregistre : AppSettings.edit(ctx) { glass = true } */
    fun edit(ctx: Context, block: AppSettings.() -> Unit) {
        this.block()
        save(ctx)
    }
}

data class Palette(
    val bg: Color,
    val card: Color,
    val text: Color,
    val secondary: Color,
    val separator: Color,
    val chip: Color,
    val accent: Color,
    val dark: Boolean,
    val glass: Boolean
)

val LocalPalette = compositionLocalOf<Palette> { error("Palette manquante") }

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = when (AppSettings.themeMode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val accent = AppSettings.accentColor
    val p = if (dark) {
        Palette(Color.Black, Color(0xFF1C1C1E), Color.White, Color(0xFF8E8E93), Color(0xFF38383A), Color(0xFF2C2C2E), accent, true, AppSettings.glass)
    } else {
        Palette(Color(0xFFF2F2F7), Color.White, Color.Black, Color(0xFF8A8A8E), Color(0xFFD1D1D6), Color(0xFFE5E5EA), accent, false, AppSettings.glass)
    }

    val scheme = if (dark) {
        darkColorScheme(
            primary = accent, onPrimary = Color.White,
            background = p.bg, onBackground = p.text,
            surface = p.card, onSurface = p.text,
            surfaceVariant = p.chip, onSurfaceVariant = p.secondary,
            outline = p.separator,
            surfaceContainer = p.card, surfaceContainerHigh = p.card, surfaceContainerHighest = p.chip
        )
    } else {
        lightColorScheme(
            primary = accent, onPrimary = Color.White,
            background = p.bg, onBackground = p.text,
            surface = p.card, onSurface = p.text,
            surfaceVariant = p.chip, onSurfaceVariant = p.secondary,
            outline = p.separator,
            surfaceContainer = p.card, surfaceContainerHigh = p.card, surfaceContainerHighest = p.chip
        )
    }

    // Les icônes de la barre d'état suivent le thème choisi dans l'appli
    val activity = LocalContext.current as? ComponentActivity
    LaunchedEffect(dark) {
        activity?.enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) { dark },
            navigationBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) { dark }
        )
    }

    // Taille du texte réglable
    val d = LocalDensity.current
    CompositionLocalProvider(
        LocalPalette provides p,
        LocalContentColor provides p.text,
        LocalDensity provides Density(d.density, d.fontScale * AppSettings.textScale)
    ) {
        MaterialTheme(colorScheme = scheme) {
            Backdrop(p, content)
        }
    }
}

@Composable
private fun Backdrop(p: Palette, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize().background(p.bg)) {
        when (AppSettings.bgMode) {
            1 -> {
                val g = BG_GRADIENTS[AppSettings.bgGradient.coerceIn(0, BG_GRADIENTS.lastIndex)]
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(if (p.dark) g.third else g.second)))
            }
            2 -> {
                val bmp = remember(AppSettings.bgImageVersion) { Media.loadBackground(ctx) }
                if (bmp != null) {
                    val blurRadius = AppSettings.bgBlur
                    Image(
                        bmp, null,
                        Modifier.fillMaxSize().then(
                            if (blurRadius > 0) Modifier.blur(blurRadius.dp, BlurredEdgeTreatment.Unbounded) else Modifier
                        ),
                        contentScale = ContentScale.Crop
                    )
                    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = AppSettings.bgDim)))
                }
            }
            3 -> {
                val sky = if (p.dark) listOf(Color(0xFF0A1022), Color(0xFF1B1033)) else listOf(Color(0xFFE6EEFF), Color(0xFFF6E9FF))
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(sky)))
                val a = if (p.dark) 0.50f else 0.38f
                Box(
                    Modifier.align(Alignment.TopStart).offset((-70).dp, 40.dp).size(300.dp)
                        .blur(80.dp, BlurredEdgeTreatment.Unbounded)
                        .background(p.accent.copy(alpha = a), CircleShape)
                )
                Box(
                    Modifier.align(Alignment.CenterEnd).offset(90.dp, 0.dp).size(260.dp)
                        .blur(80.dp, BlurredEdgeTreatment.Unbounded)
                        .background(Color(0xFFFF2D55).copy(alpha = a * 0.7f), CircleShape)
                )
                Box(
                    Modifier.align(Alignment.BottomStart).offset((-40).dp, 60.dp).size(280.dp)
                        .blur(80.dp, BlurredEdgeTreatment.Unbounded)
                        .background(Color(0xFF30B0C7).copy(alpha = a * 0.7f), CircleShape)
                )
            }
            else -> {
                val c = when {
                    AppSettings.bgColor == -2 -> Color(AppSettings.bgCustom)
                    AppSettings.bgColor in BG_COLORS.indices ->
                        BG_COLORS[AppSettings.bgColor].let { if (p.dark) it.dark else it.light }
                    else -> p.bg
                }
                Box(Modifier.fillMaxSize().background(c))
            }
        }
        content()
    }
}

/** Fond des « cartes » : blanc / gris foncé, ou verre translucide si le style Verre est actif. */
@Composable
fun Modifier.card(shape: Shape = RoundedCornerShape(AppSettings.cornerRadius.dp)): Modifier {
    val p = LocalPalette.current
    return if (p.glass) {
        val top = if (p.dark) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.55f)
        val bottom = if (p.dark) Color.White.copy(alpha = 0.06f) else Color.White.copy(alpha = 0.28f)
        this.clip(shape)
            .background(Brush.verticalGradient(listOf(top, bottom)), shape)
            .border(
                1.dp,
                Brush.linearGradient(listOf(Color.White.copy(alpha = 0.9f), Color.White.copy(alpha = 0.15f), Color.White.copy(alpha = 0.5f))),
                shape
            )
    } else {
        this.clip(shape).background(p.card, shape)
    }
}
