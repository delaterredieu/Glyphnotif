package com.example.glyphnotif

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

// ====================================================================== fenêtres dans la charte graphique

/** Fenêtre centrée aux couleurs de l'appli (remplace les menus déroulants). */
@Composable
fun AppDialog(title: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth(0.92f).heightIn(max = 600.dp)
                .clip(RoundedCornerShape((AppSettings.cornerRadius + 4).dp))
                .background(p.card).padding(16.dp)
        ) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 12.dp))
            content()
        }
    }
}

@Composable
fun SearchField(value: String, onChange: (String) -> Unit, placeholder: String = "Rechercher") {
    val p = LocalPalette.current
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(p.chip).padding(horizontal = 12.dp, vertical = 10.dp)) {
        BasicTextField(
            value, onChange, singleLine = true,
            textStyle = TextStyle(color = p.text, fontSize = 16.sp),
            cursorBrush = SolidColor(p.accent),
            modifier = Modifier.fillMaxWidth(),
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) Text(placeholder, color = p.secondary, fontSize = 16.sp)
                    inner()
                }
            }
        )
    }
}

data class Choice(val key: String, val label: String, val sub: String? = null)

@Composable
fun ChoiceDialog(
    title: String,
    choices: List<Choice>,
    selected: String?,
    searchable: Boolean = false,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val p = LocalPalette.current
    var q by remember { mutableStateOf("") }
    val list = if (q.isBlank()) choices else choices.filter {
        it.label.contains(q, ignoreCase = true) || (it.sub?.contains(q, ignoreCase = true) == true)
    }
    AppDialog(title, onDismiss) {
        if (searchable) {
            SearchField(q, { q = it })
            Spacer(Modifier.height(8.dp))
        }
        LazyColumn(Modifier.weight(1f, fill = false)) {
            itemsIndexed(list, key = { i, c -> "$i-${c.key}" }) { _, c ->
                Row(
                    Modifier.fillMaxWidth().clickable { onPick(c.key) }.padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(c.label, color = p.text, fontSize = 16.sp)
                        val sub = c.sub
                        if (sub != null) Text(sub, color = p.secondary, fontSize = 13.sp)
                    }
                    if (c.key == selected) Text("✓", color = p.accent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.fillMaxWidth().height(0.5.dp).background(p.separator))
            }
        }
        TextButton(onDismiss, Modifier.align(Alignment.End)) { Text("Fermer", color = p.accent) }
    }
}

/** Ligne qui ouvre un choix dans une fenêtre centrée. */
@Composable
fun ChoiceRow(
    title: String,
    choices: List<Choice>,
    selected: String,
    searchable: Boolean = false,
    onPick: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val label = choices.firstOrNull { it.key == selected }?.label ?: selected
    NavRow(title, value = label) { open = true }
    if (open) {
        ChoiceDialog(title, choices, selected, searchable, onPick = { onPick(it); open = false }, onDismiss = { open = false })
    }
}

data class DialogAction(val label: String, val destructive: Boolean = false, val onClick: () -> Unit)

@Composable
fun ActionDialog(title: String, actions: List<DialogAction>, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    AppDialog(title, onDismiss) {
        actions.forEach { a ->
            Text(
                a.label, fontSize = 17.sp, color = if (a.destructive) Red else p.text,
                modifier = Modifier.fillMaxWidth().clickable { onDismiss(); a.onClick() }.padding(vertical = 14.dp)
            )
            Box(Modifier.fillMaxWidth().height(0.5.dp).background(p.separator))
        }
        TextButton(onDismiss, Modifier.align(Alignment.End)) { Text("Annuler", color = p.accent) }
    }
}

// ====================================================================== durées

@Composable
fun StepButton(label: String, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(p.chip).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = p.accent, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
    }
}

private val DURATION_PRESETS = listOf(500, 1000, 2000, 3000, 5000, 10000, 30000, 60000)

private fun stepFor(v: Int): Int = when {
    v < 2000 -> 250
    v < 10000 -> 500
    v < 60000 -> 1000
    else -> 5000
}

private fun snapMs(v: Int): Int {
    val s = when {
        v < 2000 -> 100
        v < 10000 -> 500
        v < 60000 -> 1000
        else -> 5000
    }
    return (v + s / 2) / s * s
}

/**
 * Réglage d'une durée courte comme longue : choix rapides, boutons − / + et curseur à échelle logarithmique
 * (les petites valeurs occupent beaucoup de place sur le curseur, qui est éloigné du bord de l'écran).
 */
@Composable
fun DurationRow(title: String, valueMs: Int, minMs: Int = 500, maxMs: Int = 300_000, onChange: (Int) -> Unit) {
    val p = LocalPalette.current
    val v = valueMs.coerceIn(minMs, maxMs)
    val ratio = ln(maxMs.toDouble() / minMs)
    fun toPos(ms: Int): Float = (ln(ms.toDouble() / minMs) / ratio).toFloat().coerceIn(0f, 1f)
    fun fromPos(t: Float): Int = snapMs((minMs * exp(t.toDouble() * ratio)).toInt()).coerceIn(minMs, maxMs)

    Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, fontSize = 17.sp)
            Text(fmtDur(v), fontSize = 17.sp, color = p.secondary)
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DURATION_PRESETS.filter { it in minMs..maxMs }.forEach { d ->
                Box(
                    Modifier.clip(RoundedCornerShape(10.dp)).background(if (v == d) p.accent else p.chip)
                        .clickable { onChange(d) }.padding(horizontal = 12.dp, vertical = 7.dp)
                ) {
                    Text(fmtDur(d), fontSize = 14.sp, color = if (v == d) Color.White else p.text)
                }
            }
        }
        Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            StepButton("−") { onChange((v - stepFor(v - 1)).coerceAtLeast(minMs)) }
            Slider(toPos(v), { onChange(fromPos(it)) }, modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
            StepButton("+") { onChange((v + stepFor(v)).coerceAtMost(maxMs)) }
        }
    }
}

/** Instant ou durée dans un son : curseur linéaire entre deux boutons − / +. */
@Composable
fun TimeSliderRow(title: String, valueMs: Int, maxMs: Int, stepMs: Int = 500, onChange: (Int) -> Unit) {
    val p = LocalPalette.current
    val v = valueMs.coerceIn(0, maxMs)
    Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, fontSize = 17.sp)
            Text(fmtTime(v), fontSize = 17.sp, color = p.secondary)
        }
        Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            StepButton("−") { onChange((v - stepMs).coerceAtLeast(0)) }
            Slider(
                v.toFloat(),
                { onChange(((it / stepMs).roundToInt() * stepMs).coerceIn(0, maxMs)) },
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                valueRange = 0f..maxMs.toFloat().coerceAtLeast(1f)
            )
            StepButton("+") { onChange((v + stepMs).coerceAtMost(maxMs)) }
        }
    }
}

// ====================================================================== types de notification (canaux)

/** Types de notification propres à l'appli, comme dans les réglages de notifications d'Android. */
@Composable
fun ChannelRow(pkg: String, channelId: String, channelName: String, onPick: (String, String) -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    var choices by remember { mutableStateOf<List<Choice>>(emptyList()) }
    val label = if (channelId.isEmpty()) "Tous les types" else channelName.ifEmpty { channelId }
    NavRow("Type de notification", value = label) {
        val found = NotifChannels.forPackage(ctx, pkg).map { Choice(it.id, it.name, it.group) }
        choices = listOf(Choice("", "Tous les types")) + if (found.isEmpty()) {
            listOf(Choice("__none", "Aucun type connu pour l'instant", "Active l'accès aux notifications, ou attends une première notification de cette appli"))
        } else found
        open = true
    }
    if (open) {
        ChoiceDialog(
            "Type de notification", choices, channelId, searchable = choices.size > 8,
            onPick = { id ->
                if (id != "__none") onPick(id, if (id.isEmpty()) "" else (choices.firstOrNull { it.key == id }?.label ?: ""))
                open = false
            },
            onDismiss = { open = false }
        )
    }
}

// ====================================================================== contacts

@Composable
private fun NameRow(label: String, checked: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = p.text, fontSize = 16.sp, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (checked) Text("✓", color = p.accent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

/**
 * Choix d'un ou plusieurs contacts : ceux de l'appli (WhatsApp, Signal, Telegram… quand ils sont synchronisés),
 * les conversations déjà vues dans ses notifications, puis tous les contacts du téléphone.
 */
@Composable
fun ContactPickerDialog(pkg: String, selected: List<String>, onDone: (List<String>) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    var chosen by remember { mutableStateOf(selected) }
    var q by remember { mutableStateOf("") }
    var permission by remember { mutableStateOf(Contacts.hasPermission(ctx)) }
    var appContacts by remember { mutableStateOf<List<String>>(emptyList()) }
    var phoneContacts by remember { mutableStateOf<List<String>>(emptyList()) }
    val recent = remember(pkg) { RecentStore.titles(ctx, pkg) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> permission = granted }

    LaunchedEffect(permission) {
        if (permission) {
            val (a, all) = withContext(Dispatchers.IO) { Contacts.forAccount(ctx, pkg) to Contacts.all(ctx) }
            appContacts = a
            phoneContacts = all
        }
    }

    val ql = q.trim()
    fun filt(l: List<String>) = if (ql.isEmpty()) l else l.filter { it.contains(ql, ignoreCase = true) }
    val sel = chosen
    val rec = filt(recent).filter { it !in sel }.distinct()
    val appl = filt(appContacts).filter { it !in sel }.distinct()
    val phone = filt(phoneContacts).filter { it !in sel && it !in appContacts }.distinct()

    AppDialog("Contacts", onDismiss) {
        SearchField(q, { q = it }, "Rechercher ou saisir un nom")
        if (!permission) {
            Text(
                "Autoriser l'accès aux contacts", color = p.accent, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.fillMaxWidth().clickable { launcher.launch(Manifest.permission.READ_CONTACTS) }.padding(vertical = 12.dp)
            )
        }
        LazyColumn(Modifier.weight(1f, fill = false)) {
            if (ql.isNotEmpty() && sel.none { it.equals(ql, ignoreCase = true) }) {
                item(key = "custom") { NameRow("Utiliser « $ql »", false) { chosen = sel + ql; q = "" } }
            }
            if (sel.isNotEmpty()) {
                item(key = "hs") { SectionHeader("Sélection") }
                items(sel, key = { "s$it" }) { n -> NameRow(n, true) { chosen = sel - n } }
            }
            if (rec.isNotEmpty()) {
                item(key = "hr") { SectionHeader("Vus dans les notifications de l'appli") }
                items(rec, key = { "r$it" }) { n -> NameRow(n, false) { chosen = sel + n } }
            }
            if (appl.isNotEmpty()) {
                item(key = "ha") { SectionHeader("Contacts de l'appli") }
                items(appl, key = { "a$it" }) { n -> NameRow(n, false) { chosen = sel + n } }
            }
            if (phone.isNotEmpty()) {
                item(key = "hp") { SectionHeader("Contacts du téléphone") }
                items(phone, key = { "p$it" }) { n -> NameRow(n, false) { chosen = sel + n } }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
            TextButton(onDismiss) { Text("Annuler", color = p.accent) }
            TextButton({ onDone(sel) }) { Text("OK (${sel.size})", color = p.accent, fontWeight = FontWeight.SemiBold) }
        }
    }
}

// ====================================================================== applis et sons

@Composable
fun AppPickerDialog(apps: List<AppInfo>, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var q by remember { mutableStateOf("") }
    val list = apps.filter { it.label.contains(q, ignoreCase = true) }
    AppDialog("Choisir une appli", onDismiss) {
        SearchField(q, { q = it })
        Row(
            Modifier.fillMaxWidth().clickable { onPick("") }.padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AllAppsIcon(36.dp)
            Spacer(Modifier.width(12.dp))
            Text("Toutes les applis", color = p.text, fontSize = 16.sp)
        }
        LazyColumn(Modifier.weight(1f, fill = false)) {
            items(list, key = { it.pkg }) { a ->
                Row(
                    Modifier.fillMaxWidth().clickable { onPick(a.pkg) }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppIcon(a.pkg, 36.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(a.label, color = p.text, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        TextButton(onDismiss, Modifier.align(Alignment.End)) { Text("Fermer", color = p.accent) }
    }
}

@Composable
private fun PickRow(label: String, checked: Boolean, ref: String?, onPick: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().clickable(onClick = onPick).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        if (ref != null) {
            PlayButton(SoundPlayer.playingId == ref) { SoundPlayer.togglePreview(ctx, ref, SoundLibrary.uriFor(ctx, ref)) }
            Spacer(Modifier.width(10.dp))
        }
        Text(label, color = p.text, fontSize = 16.sp, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (checked) Text("✓", color = p.accent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

/** Choix d'un son pour une règle : aucun, bibliothèque ou sons du téléphone, avec recherche et aperçu. */
@Composable
fun SoundPickerDialog(selected: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val system = remember { SoundLibrary.systemSounds(ctx) }
    var q by remember { mutableStateOf("") }
    DisposableEffect(Unit) { onDispose { SoundPlayer.stopPreview() } }
    val lib = SoundLibrary.items.filter { q.isBlank() || it.name.contains(q, ignoreCase = true) }
    val sys = system.filter { q.isBlank() || it.first.contains(q, ignoreCase = true) }
    AppDialog("Choisir un son", onDismiss) {
        SearchField(q, { q = it })
        Spacer(Modifier.height(4.dp))
        LazyColumn(Modifier.weight(1f, fill = false)) {
            item(key = "none") { PickRow("Aucun", selected.isEmpty(), null) { onPick("") } }
            if (lib.isNotEmpty()) item(key = "hl") { SectionHeader("Ma bibliothèque") }
            items(lib, key = { "l" + it.id }) { s ->
                val ref = "lib:${s.id}"
                PickRow(s.name + if (s.glyph) " · glyphtone" else "", selected == ref, ref) { onPick(ref) }
            }
            if (sys.isNotEmpty()) item(key = "hs") { SectionHeader("Sons du téléphone") }
            itemsIndexed(sys, key = { i, _ -> "s$i" }) { _, (name, uri) ->
                val ref = "sys:$uri"
                PickRow(name, selected == ref, ref) { onPick(ref) }
            }
        }
        TextButton(onDismiss, Modifier.align(Alignment.End)) { Text("Fermer", color = p.accent) }
    }
}
